# Read-only inspection tool

`inspect_workbook.py` uses only the Python standard library. It does not launch Excel, execute VBA, access the network, update links or save the source workbook. It refuses to overwrite an existing output directory.

Example from the project root after the local file is copied:

```text
python tools/inspect_workbook.py --input "input/current/Dock manager test 1.xlsm" --out "output/local_inspection_01"
```

It reads the XLSX/XLSM ZIP/XML structure, checks CRC/XML parsing, exports the structure, hyperlinks and populated cells (including formulas and stored cached values), and checks that the source hash remains unchanged. It expects transitional SpreadsheetML and conservatively limits uncompressed size. It does not parse VBA binaries or validate full Excel compatibility.

`registers.json` assumes THIS pilot's row-8 headers and row-9 data. Other workbook layouts can still be inspected, but those register summaries must not be assumed correct without checking the headers. Style-only empty cells are not in the cell snapshots; the unchanged original workbook retains them.

Never interpret cached values or successful ZIP/XML parsing as a live recalculation, compiled project, secure macro review or native Excel acceptance.
