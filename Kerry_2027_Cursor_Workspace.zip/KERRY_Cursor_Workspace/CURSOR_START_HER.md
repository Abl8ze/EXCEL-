# Opgave til Cursor: fejlfind KERRY Drydock 2027 i Excel/VBA

Læs hele instruktionen og de faktiske filer, før du ændrer noget. Begynd med en diagnose og en kort reparationsplan. Jeg er ikke programmør: forklar på dansk og giv kun ét konkret manuelt trin ad gangen. Excel-løsningen skal fortsat være på engelsk.

## 1. Prioriteten lige nu

Få den eksisterende testfil til at kompilere, starte automatiseringen, opdatere begge veje og gemme/lukke/genåbne korrekt. Undersøg hele projektet – ikke endnu en isoleret linjerettelse uden at gennemgå resten. Foretag ikke en større ombygning, før fejlårsager og dataforbindelser er forstået.

Dette er **KERRY-jobtrackeren**, ikke et andet projekt med synkronisering mellem fire skibes separate Excel-filer. Tovejskommunikation betyder her redigering mellem faner i den samme projektmappe.

## 2. Filer og sandhedskilder

Min aktuelle testfil hedder **Dock manager test 1.xlsm**. Jeg har selv gemt den i Excel ud fra `Kerry_2027_Professional_Pilot.xlsx` og importeret kode. Den lokale fil er ikke uploadet til denne samtale; den skal lægges i `input/current`. Hvis den mangler, sig det og undersøg kun reference- og kildefilerne foreløbigt.

- `input/reference/Kerry_2027_Professional_Pilot.xlsx`: kildemappen til det nuværende professionelle pilotlayout. Ingen indbyggede makroer.
- `input/reference/Kerry_2027_Clean.xlsx`: tidligere ren grundfil, som jeg udtrykkeligt har bekræftet kunne åbnes. Bevar den.
- `input/reference/Original_quotation_tracker.xlsx`: original upload med historiske data; ikke en erstatning for den seneste lokale fil.
- `src/current/KerryPilot.bas`: byte-identisk med seneste `KerryPilot_CompileFix_v2.bas`. Filen er blot lagt under standardnavnet. Det interne modulnavn er **KerryPilot**.
- `src/current/CKerryEvents.cls`: klassemodulet **CKerryEvents**.
- `src/history`: tidligere versioner af samme standardmodul. **De må ikke alle importeres.**
- `snapshots/reference_pilot`: læsbare udtræk fra reference-piloten, ikke fra min lokale `.xlsm`.

Kontrollér hvilken kode der faktisk er importeret i `.xlsm`. En ny `.bas` i mappen betyder ikke, at koden er importeret i Excel. Kontroller navne, dubletter, modul-/klasseplacering og kildeforskelle. Eksportér eventuelt det lokale projekt til en separat mappe med Excels egne funktioner, hvis tilladt.

De tidligere genererede .xlsm-filer og en ældre xlsx-gendannelseskopi blev afvist som korrupte. Den præcise årsag blev ikke fastslået. De er ikke med i pakken. Det aktuelle synlige problem er **VBA-kompilering**, ikke at den nuværende lokale testfil ikke kan åbnes.

## 3. Konkrete fejl og versionshistorik

### Fejl A: Compile error: Syntax error

Excel markerede:

```vb
Private Function RateFor(ByVal currency As String) As Double
```

I senere kode er parameteren omdøbt til `currencyCode`. Undersøg den faktiske importerede version og alle referencer. Se `evidence/errors/01_Syntax_error_RateFor.png`.

### Fejl B: Compile error: Duplicate declaration in current scope

Fejlen blev vist i **RunPilotChecks**. Se `evidence/errors/02_Duplicate_declaration_RunPilotChecks.png`.

Et konkret kontrolpunkt i gammel kode er gentagne linjer:

```vb
RefreshAll: ConfigureEditors True: SnapshotSources
```

Undersøg om `RefreshAll:` fortolkes som en gentaget label i stedet for et procedurekald. I v2 er de to steder ændret til:

```vb
Call RefreshAll
ConfigureEditors True
SnapshotSources
```

V2 har også navne som `PilotChecksError`, `PilotChecksRestore` og `failureCount`. Det er endnu **ikke bekræftet**, at v2 kompilerer eller kører i Excel. Se de faktiske diffs i `docs/`.

Gennemgå alle procedurer for reserverede navne, dobbelte deklarationer, gentagne labels, tvetydige navne, manglende procedurer, argument-/objekttyper og MISSING-referencer. Undlad at fjerne funktioner eller tests alene for at få en vellykket kompilering.

## 4. Sikker undersøgelse

Lav en dateret backup, SHA-256 og en separat lokal arbejdskopi. Arbejd ikke direkte i OneDrive-arbejdsfilen. Registrér hvilken original der er kopieret og hvorhen.

Begynd read-only uden VBA-kørsel, eksterne links eller forbindelsesopdatering. `tools/inspect_workbook.py` kan udtrække OOXML-strukturen med Python-standardbiblioteket uden at køre Excel eller VBA. Værktøjet skriver kun til en NY udtræksmappe; kildemappen gemmes ikke. For lokal fil:

```text
python tools/inspect_workbook.py --input "input/current/Dock manager test 1.xlsm" --out "output/local_inspection_01"
```

Dette er ikke en VBA-parser eller en kompileringstest. Undersøg det importerede VBA-projekt separat med tilgængelige, godkendte værktøjer. Brug installeret Microsoft Excel til reel kompilering og runtime-test. Fastslå først, hvilke værktøjer/muligheder du faktisk har.

Konstruér ikke `vbaProject.bin` manuelt. Undlad at gemme den aktuelle XLSM gennem en generel Python-regnearksskriver. Bevar Excels native projekt. Ændr ikke Trust Center, registreringsdatabase, Protected View eller adgang til VBA-projektet automatisk. Ved politikblokering: forklar og stop den handling, ikke en omvej der svækker sikkerheden.

Initial programmatisk åbning må ikke utilsigtet køre `Auto_Open`/workbook events. Ved eventuel Excel-automation skal makroer undertrykkes under den indledende læsning, eksterne opdateringer fravælges og tidligere Application-indstillinger gendannes. Se officielle kilder i `docs/SOURCES.md`. XML/CRC-check og openpyxl-indlæsning er ikke bevis for native Excel-kompatibilitet.

## 5. Forbindelsen mellem VBA og ark

Kortlæg de faktiske ark, kolonner, navne, datavalideringer, beskyttelser, flettede celler, links og knapper først. Se `docs/DATA_MODEL.md` for verificerede mappinger fra referencefilen; kontrollér dem mod den lokale fil.

Relevante ark: Overview, Budget, Jobs, Suppliers, Supplier Jobs, Quotes, Negotiation Savings, Print Summary, Create Job, Add Supplier, Test Results, Vessel, Lists og JOB 3103.01.

Skjulte hjælpe-/arkivark omfatter `_Control`, `_PilotState`, `_PilotLists`, `_JobTemplate` og Archive-ark. De må ikke slettes som oprydning.

Undersøg særligt:

- StartPilot, Auto_Open og kontrol af korrekt filformat/pilotversion.
- CKerryEvents, `Public WithEvents Book As Excel.Workbook` og eventobjektets levetid.
- HandleChange, HandleActivate, HandleFollowLink, RefreshAll og ConfigureEditors.
- JobMap, ContactMap, QuoteMap, ID-opslag og opdatering af navngivne lister.
- ValidatePlan, CommitPlan, SnapshotSources, rollback og afvisning af ugyldige input.
- CreateJob, SaveSupplierQuote og genbrug af leverandører/kontakter uden duplikering.
- BeforeWorkbookSave, AfterWorkbookSave og genoprettelse af eventbehandling efter gemning/fejl.
- RunPilotChecks, initialisering af snapshots og gendannelse på ALLE fejlveje.

Kontrollér at mBusy, mActive, mTesting, mSaving og Application-indstillinger ikke bliver låst efter en fejl. Håndtér flettede felter, paste af flere celler, sortering og filtrering. Redigering må aldrig flyttes til et andet tilbud, fordi en række har flyttet sig. Brug ID'er, ikke visningsrækken som identitet.

Tidligere versioner brugte andre priskolonner: i den medfølgende pilot er **Quotes G original pris og H slutpris**. Genbrug ikke gammel vejledning om H/AD uden at se den aktuelle mapping.

## 6. Den ønskede jobbaserede arbejdsgang

Jobbet er omdrejningspunktet. Jeg åbner Jobs/Overview, vælger Create Job, vælger et katalogjob og får en jobfane. Et eksisterende job skal åbnes uden dublet.

Jobsiden samler jobnummer/titel, afdeling, jobstatus, stort dock-specifikationsfelt, noter/dokumentlinks og tilbuddets leverandør, kontakt, status, valuta, original pris, slutpris, oprindeligt/revideret tilbudslink og valg til budgettet. Tilbudssammenligningen skal vise alle tilbud til netop dette job.

Add Supplier / Quote skal kunne genbruge eksisterende kontakt, tilføje ny kontakt hos eksisterende virksomhed eller oprette ny leverandør med automatisk unikt ID. Registrene opdateres uden dobbeltindtastning.

JobID, SupplierID, ContactID og QuoteID er forskellige nøgler. Virksomhedsnavn er fælles for samme SupplierID, telefon/e-mail følger ContactID, og pris/status/Selected følger det konkrete QuoteID. Kontaktrettelser kan gælde flere jobs, men valg af et tilbud til job A må ikke vælge et tilbud til job B.

Tovejskommunikation er et krav: ret på jobsiden og se rettelsen i de relevante registre; ret i registre og se rettelsen på jobsiden. Suppliers er et fælles overblik, hvorfra jeg via Supplier Jobs kan se leverandørens tilbud og åbne det tilknyttede job.

Dropdowns skal anvende fælles, eksisterende valglister, ikke nye lokale statusvarianter. Open Job fra Overview/Jobs/Suppliers-relaterede visninger må kun være aktivt, når jobfanen eksisterer. Tilbagegenveje skal forblive synlige.

### Pilotafgrænsning

**JOB 3103.01 / 3103.01-Q1** er det forberedte redigerbare RENK-job. De øvrige 11 eksisterende jobfaner er rapportvisninger i denne pilot. Nye jobs oprettet gennem Create Job er tiltænkt som redigerbare. Bekræft denne afgrænsning; test piloten først. Den fulde målsætning er senere redigerbare jobfaner for alle oprettede jobs, men udvid ikke ukritisk før test.

## 7. Økonomiregler

- Besparelse = original pris minus gyldig slutpris, med ens valutaomregning.
- Tom slutpris: brug original pris; registrér ingen besparelse.
- Numerisk 0 er en gyldig slutpris og ikke en tom celle.
- Højere slutpris giver negativ besparelse, ikke en skjult nulværdi.
- Negative indtastningspriser afvises tydeligt, tidligere gyldige værdier bevares.
- Kun Selected-tilbud indgår i valgt budget og samlet valgt besparelse.
- Flere leverandører kan vælges til forskellige scopes på samme job; to konkurrerende tilbud på samme scope må ikke utilsigtet dobbelttælles.
- Kurser hentes fra Lists. Kontrollér enheder pr. EUR før division/multiplikation; kurserne er gemte antagelser, ikke livekurser.
- Budget, Negotiation Savings, Suppliers, jobfaner og Print Summary skal stemme overens. Besparelsesprocentens nævner skal være korrekt og forklaret.

## 8. Test med observeret resultat

Læs først testkoden kritisk; den er ikke bevis for sig selv. Brug `docs/ACCEPTANCE_TESTS.md` og en separat testkopi, aldrig den delte arbejdsfil. Rapportér PASS, FAIL eller IKKE TESTET, ikke gæt.

Test compilation; StartPilot; knapper uden dubletter; 44.800 til 40.000 EUR = 4.800 EUR sparet; budget/restbudget; redigering begge veje gennem Jobs/Quotes/Supplier Jobs/Suppliers; status/Selected; tom/0/højere/negativ pris; valuta; kontakt-scope; sortering/paste; ID-integritet; job- og leverandøroprettelse; links; dropdowns; gem/luk/genåbn; fejlveje og deaktiverede makroer.

RunPilotChecks laver midlertidige ændringer. Gendannelse skal verificere ALLE ændrede felter, inklusive original pris, slutpris, valuta, scope, kontakt, status og aktivt tilbud. Hvis det ikke lykkes, skal testkopien kasseres uden at overskrive baseline. Et gammelt TEST_REPORT med PASS er ikke dokumentation for runtime nu.

## 9. Bevar data og professionelt layout

Tidligere og nu referenceoptælling: 81 jobs, 22 tilbud, 14 virksomheder, 16 kontaktposter, 19 oprindelige tilbudslinks og 12 jobfaner. Optæl den aktuelle lokale fil på ny: nye oplysninger må ikke slettes for at ramme historiske tal. Arkivark er snapshots, ikke ekstra aktive poster i budgettet.

Alle priser, noter, specifikationer, kontakter, links og referencer skal bevares. Selve PDF-tilbuddene er ikke i pakken; test linkbevaring uden automatisk at hente fortrolige dokumenter. Et bevaret URL er ikke bevis for adgang til SharePoint/lokal fil.

Layout skal være brugervenligt, professionelt og læsbart på alle faner. Brug skærmens bredde med luft omkring indholdet, to brede jobpaneler, store tekstfelter, tydelige dropdowns, faste genveje, overskuelige registre og et professionelt ringdiagram. Print Summary skal samle budget/besparelser og de valgte tilbud med kontakter. Funktion skal repareres først; layoutændringer må ikke bryde mappinger, print, formler eller knapper.

## 10. Leverance

Start med at fortælle hvilken fil/kodeversion du faktisk har læst, konstaterede fejl, mistanker, manglende adgang og din reparationsplan. Skeln mellem det lokale VBA-projekt, reference-XLSX og tekstudtræk.

Lav derefter én sammenhængende rettelse i testkopien, dokumenter diffs, procedurer/linjer, sikkerhedskopier og fulde testresultater. Bevar modulnavnene KerryPilot og CKerryEvents. Lever helst native Excel-gemt test-XLSM og tilsvarende kildekode; ellers sig præcist hvad du ikke kunne udføre. Ingen falsk bekræftelse af kompilering eller funktion.

Begynd nu med `docs/CURRENT_STATUS.md`, filinventaret og den aktuelle testfil i `input/current`. Tidligere påstande om “rettet” og “fungerer” er ikke bevis.
