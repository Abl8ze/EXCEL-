# Native Excel acceptance checklist

Initial state of every test below: **NOT TESTED** for the latest source in the user's local XLSM.
Record workbook hash, module hashes, Excel version/bitness, macro policy constraints and copy location first.
Do not run tests against a shared or live working file. Audit the test routine before executing it.

| ID | Test | Expected observable result | Status |
|---|---|---|---|
| T01 | Actual imported source | Exactly one KerryPilot and one CKerryEvents; version/diff documented | NOT TESTED |
| T02 | Native compile | Debug > Compile VBAProject completes without compile errors; references not missing | NOT TESTED |
| T03 | Startup | StartPilot succeeds; correct workbook/pilot guard, live event object, controls installed | NOT TESTED |
| T04 | Repeated startup | Starting twice does not duplicate controls or event side effects | NOT TESTED |
| T05 | Final price from job | 44,800 original / 40,000 final EUR gives 4,800 saved; Quotes and all relevant views agree | NOT TESTED |
| T06 | Budget | Selected cost decreases by 4,800; remaining allowance rises by 4,800 | NOT TESTED |
| T07 | Reverse editing | Quotes final-price edit returns to job; Supplier Jobs edit updates same QuoteID | NOT TESTED |
| T08 | Empty final | Original retained for selected cost; no negotiated saving recorded | NOT TESTED |
| T09 | Numeric zero | Zero accepted as final; not converted to empty or original price | NOT TESTED |
| T10 | Increased final | 46,000 final against 44,800 original shows -1,200 saving | NOT TESTED |
| T11 | Invalid negative | Invalid input rejected; previous valid value restored with clear feedback | NOT TESTED |
| T12 | Currency | Saved units-per-EUR rates used consistently; unknown/zero FX rejected or explicitly flagged | NOT TESTED |
| T13 | Quote selection | Unselected quote excluded; selecting returns correct amounts; no unrelated job affected | NOT TESTED |
| T14 | Competing scopes | Same-scope competing quotes cannot silently double count; separate scopes may be selected | NOT TESTED |
| T15 | Shared identity | Supplier rename propagates within SupplierID; contact fields stay within ContactID | NOT TESTED |
| T16 | Contact two-way | Job phone/email changes reach Suppliers; reverse changes reach relevant job views | NOT TESTED |
| T17 | Status/dropdowns | Shared existing lists work in all editable surfaces; invalid paste rejected consistently | NOT TESTED |
| T18 | Sort/filter/paste | Changes find correct IDs after sort/filter; multi-cell paste validates and rolls back atomically | NOT TESTED |
| T19 | Create Job | Catalog job gets one editable page, links, mappings and shared dropdowns; reselect opens same page | NOT TESTED |
| T20 | Add supplier/quote | Existing contact reused or unique IDs created; job/supplier/quote relationships correct | NOT TESTED |
| T21 | Navigation | Existing jobs accessible from Overview/Jobs/Supplier Jobs; no link to nonexistent page; back links work | NOT TESTED |
| T22 | Quote links | All original addresses and references preserved; revised link separate; no automatic document fetch | NOT TESTED |
| T23 | Print/dashboard | Totals agree; selected offers include contact/link info; charts/print regions remain correct | NOT TESTED |
| T24 | Save/reopen | Native XLSM saves, closes, reopens without repair; approved startup/event behavior resumes | NOT TESTED |
| T25 | Macros disabled | No misleading writable unsynchronized job fields; instructions/status clear | NOT TESTED |
| T26 | Error cleanup | mBusy and Application/protection state restored on every injected failure path | NOT TESTED |
| T27 | Full data restoration | All temporarily touched fields/IDs/selector/formulas restored, not only three sampled values | NOT TESTED |
| T28 | Full preservation | Before/after cell data and links reconcile; archive sheets are not counted as live offers | NOT TESTED |

For each executed test record actual before/after values, source sheet/cells/IDs, visible message and pass/fail basis. Screenshots are useful for compile/dialog/layout evidence.

## RunPilotChecks audit points

The supplied routine sets test prices, status, currency, scope, phone and active quote. Verify complete snapshot acquisition before mutation. An early error must not restore uninitialized values over valid data. Require reliable cleanup on errors, and compare every touched field (original price, final price, status, currency, scope, phone, selection IDs and displayed selector). The existing restoration boolean is narrower than the full requirement: inspect the actual code, do not trust a single PASS label.

Keep an independent backup. If restoration cannot be proven, discard the disposable work copy; do not save it over the original. A successful compile alone does not satisfy event or preservation tests.
