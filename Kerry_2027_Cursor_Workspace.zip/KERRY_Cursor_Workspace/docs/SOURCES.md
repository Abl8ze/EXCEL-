# Primary documentation for the receiving agent

These are references, not instructions to change security settings. Accessed 2026-10-16.

- Cursor project instructions / AGENTS.md: https://cursor.com/docs/rules
  A root AGENTS.md provides persistent agent guidance; the user also explicitly asks the chat to read the task file.
- Microsoft VBA duplicate declaration: https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/duplicate-declaration-in-current-scope
  A scope-level name conflict must be investigated; do not assume the only possible cause from the screenshot.
- Microsoft Excel AutomationSecurity: https://learn.microsoft.com/en-us/office/vba/api/excel.application.automationsecurity
  Programmatic opening requires deliberate macro-execution control; initial inspection must not run unreviewed VBA. Excel 4.0 macros have separate caveats. Never lower organizational security to make a test run.

Internal evidence is in evidence/errors and the unchanged source files. Claims about actual workbook data use the included reference snapshots, not public web sources. The local user workbook takes precedence once provided.
