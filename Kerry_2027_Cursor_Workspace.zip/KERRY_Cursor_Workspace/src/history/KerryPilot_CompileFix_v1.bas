Attribute VB_Name = "KerryPilot"
Option Explicit
Option Compare Text

' KERRY controlled pilot. Import into the supplied workbook in native Excel.
' No shell commands, network calls, registry changes or VBA-project access.
' Source keys stay fixed. Job view edits write to a central record by its ID.
Public PilotEvents As CKerryEvents
Private mBusy As Boolean
Private mActive As Boolean
Private mTesting As Boolean
Private mSaving As Boolean
Private mSnapshot As Object
Private Const PW As String = "KerryPilot"
Private Const FIRST As Long = 9
Private Const LASTQ As Long = 258
Private Const LASTS As Long = 508

Public Sub Auto_Open()
    StartPilot
End Sub

Public Sub StartPilot()
    Dim ws As Worksheet, msg As String
    If mBusy Then Exit Sub
    On Error GoTo Failed
    If ThisWorkbook.Worksheets("_PilotState").Range("B1").Value2 <> "KERRY_PILOT_2" Then
        MsgBox "Import these modules into the supplied professional pilot workbook.", vbExclamation
        Exit Sub
    End If
    If ThisWorkbook.ReadOnly Then
        MsgBox "Save an editable local TEST copy before starting the pilot.", vbExclamation
        Exit Sub
    End If
    If Not Application.EnableEvents Then
        MsgBox "Excel events are disabled in this session. Save your other work, restart Excel, then run StartPilot again.", vbExclamation
        Exit Sub
    End If
    If ThisWorkbook.FileFormat <> xlOpenXMLWorkbookMacroEnabled Then
        MsgBox "First save this TEST copy as an Excel Macro-Enabled Workbook (.xlsm). Then run StartPilot again.", vbInformation
        Exit Sub
    End If
    mBusy = True
    Application.ScreenUpdating = False
    Set PilotEvents = New CKerryEvents
    Set PilotEvents.Book = ThisWorkbook
    mActive = True
    ThisWorkbook.Worksheets("_PilotState").Range("B2").Value2 = "ACTIVE"
    RefreshAll
    For Each ws In ThisWorkbook.Worksheets
        InstallControls ws
    Next ws
    ConfigureEditors True
    SnapshotSources
    mBusy = False
    Application.ScreenUpdating = True
    If Not mTesting Then MsgBox "Pilot ACTIVE. The prepared editable page is JOB 3103.01. Use this copy for testing only. Save the workbook, then run RunPilotChecks.", vbInformation
    Exit Sub
Failed:
    msg = Err.Description
    mActive = False
    On Error Resume Next
    ConfigureEditors False
    ThisWorkbook.Worksheets("_PilotState").Range("B2").Value2 = "NOT ACTIVE"
    mBusy = False
    Application.ScreenUpdating = True
    On Error GoTo 0
    MsgBox "Pilot did not start: " & msg & vbCrLf & "Keep the clean baseline unchanged.", vbCritical
End Sub

Public Function PilotIsActive() As Boolean
    PilotIsActive = mActive
End Function

Private Function IsPage(ByVal ws As Object) As Boolean
    On Error GoTo NoPage
    If TypeName(ws) <> "Worksheet" Then Exit Function
    IsPage = (CStr(ws.Range("AA1").Value2) = "KERRY_JOB_V2") And (ws.Name <> "_JobTemplate")
NoPage:
End Function

Private Function IsEditor(ByVal ws As Object) As Boolean
    If Not IsPage(ws) Then Exit Function
    IsEditor = (CStr(ws.Range("AA4").Value2) = "EDITABLE")
End Function

Private Function FindRow(ByVal sn As String, ByVal col As Long, ByVal ident As String) As Long
    Dim r As Long, last As Long, ws As Worksheet
    If Len(Trim$(ident)) = 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(sn)
    last = LASTQ
    If sn = "Suppliers" Then last = LASTS
    For r = FIRST To last
        If CStr(ws.Cells(r, col).Value2) = ident Then
            FindRow = r
            Exit Function
        End If
    Next r
End Function

Private Function ChoiceID(ByVal value As Variant) As String
    Dim x As String, p As Long
    If IsError(value) Then Exit Function
    x = Trim$(CStr(value)): p = InStr(1, x, " | ")
    If p > 0 Then x = Left$(x, p - 1)
    ChoiceID = Trim$(x)
End Function

Private Function HasSheet(ByVal name As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(name)
    HasSheet = Not ws Is Nothing
    On Error GoTo 0
End Function

Private Function PageForJob(ByVal jobID As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If IsPage(ws) Then
            If CStr(ws.Range("AA2").Value2) = jobID Then
                Set PageForJob = ws
                Exit Function
            End If
        End If
    Next ws
End Function

Private Function JobMap() As Variant
    JobMap = Array(Array("D15", 2), Array("D18", 3), Array("D19", 4), Array("D20", 9), Array("D21", 10), Array("J21", 11), Array("A24", 13), Array("A43", 12), Array("A51", 14))
End Function

Private Function ContactMap() As Variant
    ContactMap = Array(Array("P18", 2), Array("P19", 3), Array("P21", 5), Array("P22", 6), Array("P23", 7), Array("P24", 8), Array("A56", 9))
End Function

Private Function QuoteMap() As Variant
    QuoteMap = Array(Array("P27", 5), Array("P28", 6), Array("P29", 9), Array("P30", 7), Array("P31", 8), Array("P33", 13), Array("P34", 10), Array("P35", 11), Array("P36", 12), Array("P37", 18), Array("M40", 14), Array("M44", 15), Array("M49", 17), Array("M54", 16))
End Function

Private Function SourceArea(ByVal sn As String) As String
    Select Case sn
        Case "Jobs": SourceArea = "A9:R258"
        Case "Suppliers": SourceArea = "A9:Q508"
        Case "Quotes": SourceArea = "A9:T258"
        Case "Vessel": SourceArea = "G8:G19"
        Case "Lists": SourceArea = "F9:F14"
    End Select
End Function

Private Sub SnapshotSources()
    Dim sn As Variant
    Set mSnapshot = CreateObject("Scripting.Dictionary")
    For Each sn In Array("Jobs", "Suppliers", "Quotes", "Vessel", "Lists")
        mSnapshot.Add CStr(sn), ThisWorkbook.Worksheets(CStr(sn)).Range(SourceArea(CStr(sn))).Formula
    Next sn
End Sub

Private Sub RollbackSources()
    Dim sn As Variant
    If mSnapshot Is Nothing Then Exit Sub
    For Each sn In mSnapshot.Keys
        ThisWorkbook.Worksheets(CStr(sn)).Unprotect PW
        ThisWorkbook.Worksheets(CStr(sn)).Range(SourceArea(CStr(sn))).Formula = mSnapshot(sn)
    Next sn
End Sub

Private Sub SetData(ByVal cell As Range, ByVal value As Variant)
    If IsEmpty(value) Or Len(CStr(value)) = 0 Then
        cell.ClearContents
    ElseIf VarType(value) = vbString Then
        If Left$(CStr(value), 1) = "=" Then
            cell.Value2 = "'" & CStr(value)
        Else
            cell.Value2 = value
        End If
    Else
        cell.Value2 = value
    End If
End Sub

Private Sub PutPlan(ByVal plan As Collection, ByVal sn As String, ByVal row As Long, ByVal col As Long, ByVal value As Variant)
    If row < FIRST Then Err.Raise vbObjectError + 220, , "No matching record. Select a valid job, contact or quote first."
    plan.Add Array(sn, row, col, value)
End Sub

Private Function Proposed(ByVal plan As Collection, ByVal sn As String, ByVal row As Long, ByVal col As Long) As Variant
    Dim item As Variant
    Proposed = ThisWorkbook.Worksheets(sn).Cells(row, col).Value2
    For Each item In plan
        If item(0) = sn And item(1) = row And item(2) = col Then Proposed = item(3)
    Next item
End Function

Private Function Allowed(ByVal value As Variant, ByVal listName As String, Optional ByVal blankOK As Boolean = True) As Boolean
    Dim cell As Range
    If IsError(value) Then Exit Function
    If Len(Trim$(CStr(value))) = 0 Then Allowed = blankOK: Exit Function
    For Each cell In ThisWorkbook.Names(listName).RefersToRange.Cells
        If CStr(cell.Value2) = CStr(value) Then Allowed = True: Exit Function
    Next cell
End Function

Private Function ValidMoney(ByVal value As Variant) As Boolean
    If IsError(value) Then Exit Function
    If Len(CStr(value)) = 0 Then ValidMoney = True: Exit Function
    If Not IsNumeric(value) Then Exit Function
    ValidMoney = (CDbl(value) >= 0)
End Function

Private Function ValidDate(ByVal value As Variant) As Boolean
    Dim n As Double
    If IsError(value) Then Exit Function
    If Len(CStr(value)) = 0 Then ValidDate = True: Exit Function
    On Error GoTo Bad
    If IsNumeric(value) Then
        n = CDbl(value)
    ElseIf IsDate(value) Then
        n = CDbl(CDate(value))
    Else
        Exit Function
    End If
    ValidDate = (n >= CDbl(DateSerial(2000, 1, 1)) And n <= CDbl(DateSerial(2100, 12, 31)))
Bad:
End Function

Private Function RateFor(ByVal currencyCode As String) As Double
    Dim r As Long, x As Variant
    For r = 9 To 14
        If ThisWorkbook.Worksheets("Lists").Cells(r, 5).Value2 = currencyCode Then
            x = ThisWorkbook.Worksheets("Lists").Cells(r, 6).Value2
            If IsNumeric(x) Then RateFor = CDbl(x)
            Exit Function
        End If
    Next r
End Function

Private Function ValidatePlan(ByVal plan As Collection) As String
    Dim item As Variant, sn As String, r As Long, c As Long, x As Variant
    Dim qrows As Object, key As Variant, cr As Long, cur As String, orig As Variant, fin As Variant
    Set qrows = CreateObject("Scripting.Dictionary")
    For Each item In plan
        sn = CStr(item(0)): r = CLng(item(1)): c = CLng(item(2)): x = item(3)
        If IsError(x) Then ValidatePlan = "An input contains an Excel error.": Exit Function
        Select Case sn
            Case "Jobs"
                If c = 2 And Len(Trim$(CStr(x))) = 0 Then ValidatePlan = "A job title is required."
                If c = 3 And Not Allowed(x, "lstDepartment", False) Then ValidatePlan = "Choose a department from the shared list."
                If c = 4 And Not Allowed(x, "lstJobStatus", False) Then ValidatePlan = "Choose a job status from the shared list."
                If (c = 10 Or c = 11) And Not ValidDate(x) Then ValidatePlan = "Enter a valid job date."
            Case "Suppliers"
                If c = 2 And Len(Trim$(CStr(x))) = 0 Then ValidatePlan = "A company name is required."
            Case "Quotes"
                qrows(CStr(r)) = True
                If c = 2 And FindRow("Jobs", 1, CStr(x)) = 0 Then ValidatePlan = "JobID does not exist in Jobs."
                If c = 4 And FindRow("Suppliers", 4, CStr(x)) = 0 Then ValidatePlan = "ContactID does not exist in Suppliers."
                If c = 6 And Not Allowed(x, "lstQuoteStatus", False) Then ValidatePlan = "Choose a quote status from the shared list."
                If (c = 7 Or c = 8) And Not ValidMoney(x) Then ValidatePlan = "Prices must be numeric and non-negative, or empty."
                If c = 9 And Not Allowed(x, "lstCurrency") Then ValidatePlan = "Choose a currency from the shared list."
                If (c >= 10 And c <= 12) And Not ValidDate(x) Then ValidatePlan = "Enter a valid quote date."
                If c = 18 And Not Allowed(x, "lstYesNo") Then ValidatePlan = "Sample must be Yes, No or empty."
            Case "Vessel"
                If r = 17 And Not ValidMoney(x) Then ValidatePlan = "The allowance must be a non-negative number."
                If r = 18 And Not Allowed(x, "lstCurrency", False) Then ValidatePlan = "Choose an allowance currency."
                If r = 19 And Not ValidDate(x) Then ValidatePlan = "Enter a valid status date."
            Case "Lists"
                If Not IsNumeric(x) Then
                    ValidatePlan = "An exchange rate must be numeric."
                ElseIf CDbl(x) <= 0 Then
                    ValidatePlan = "An exchange rate must be greater than zero."
                End If
        End Select
        If Len(ValidatePlan) > 0 Then Exit Function
    Next item
    For Each key In qrows.Keys
        r = CLng(key)
        If CStr(Proposed(plan, "Quotes", r, 6)) = "Selected" Then
            If Len(Trim$(CStr(Proposed(plan, "Quotes", r, 5)))) = 0 Then ValidatePlan = "A selected offer needs a scope / package.": Exit Function
            If FindRow("Jobs", 1, CStr(Proposed(plan, "Quotes", r, 2))) = 0 Then ValidatePlan = "A selected offer needs a valid job.": Exit Function
            cr = FindRow("Suppliers", 4, CStr(Proposed(plan, "Quotes", r, 4)))
            If cr = 0 Then ValidatePlan = "A selected offer needs a valid contact.": Exit Function
            cur = CStr(Proposed(plan, "Quotes", r, 9))
            If RateFor(cur) <= 0 Then ValidatePlan = "A selected offer needs a valid currency and FX rate.": Exit Function
            orig = Proposed(plan, "Quotes", r, 7): fin = Proposed(plan, "Quotes", r, 8)
            If Len(CStr(orig)) = 0 Or Not ValidMoney(orig) Then ValidatePlan = "Enter the original quote price before selecting the offer.": Exit Function
            If Not ValidMoney(fin) Then ValidatePlan = "The final price is invalid.": Exit Function
        End If
    Next key
End Function

Private Function ResolveSelections(ByVal plan As Collection) As Boolean
    Dim item As Variant, target As Object, key As Variant, r As Long, j As Long
    Dim jobID As String, scope As String, msg As String, replace As Collection, v As Variant
    Set target = CreateObject("Scripting.Dictionary"): Set replace = New Collection
    For Each item In plan
        If item(0) = "Quotes" Then
            If item(2) = 2 Or item(2) = 5 Or item(2) = 6 Then target(CStr(item(1))) = True
        End If
    Next item
    For Each key In target.Keys
        r = CLng(key)
        If CStr(Proposed(plan, "Quotes", r, 6)) = "Selected" Then
            jobID = CStr(Proposed(plan, "Quotes", r, 2))
            scope = Trim$(CStr(Proposed(plan, "Quotes", r, 5)))
            For j = FIRST To LASTQ
                If j <> r And Len(CStr(ThisWorkbook.Worksheets("Quotes").Cells(j, 1).Value2)) > 0 Then
                    If CStr(Proposed(plan, "Quotes", j, 2)) = jobID And Trim$(CStr(Proposed(plan, "Quotes", j, 5))) = scope And CStr(Proposed(plan, "Quotes", j, 6)) = "Selected" Then
                        If target.Exists(CStr(j)) Then
                            MsgBox "Two selected offers have the same job and scope in this edit. Select one, or use distinct scope names for different deliveries.", vbExclamation
                            Exit Function
                        End If
                        msg = "Another offer is selected for job " & jobID & " / " & scope & ":" & vbCrLf & ThisWorkbook.Worksheets("Quotes").Cells(j, 1).Value2 & vbCrLf & vbCrLf & "Replace that selection? The previous offer will return to Quote received."
                        If mTesting Then Exit Function
                        If MsgBox(msg, vbYesNo + vbQuestion, "Confirm selection change") <> vbYes Then Exit Function
                        replace.Add Array("Quotes", j, 6, "Quote received")
                    End If
                End If
            Next j
        End If
    Next key
    For Each v In replace: plan.Add v: Next v
    ResolveSelections = True
End Function

Private Sub CommitPlan(ByVal plan As Collection)
    Dim item As Variant, ws As Worksheet, r As Long, cidRow As Long, sid As String, value As Variant
    For Each item In plan
        Set ws = ThisWorkbook.Worksheets(CStr(item(0)))
        ws.Unprotect PW
        value = item(3)
        If item(0) = "Quotes" And (item(2) = 7 Or item(2) = 8) Then
            If Len(CStr(value)) > 0 Then value = CDbl(value)
        End If
        SetData ws.Cells(CLng(item(1)), CLng(item(2))), value
    Next item
    ' The company name is shared by SupplierID; other contact fields use ContactID.
    For Each item In plan
        If item(0) = "Suppliers" And item(2) = 2 Then
            Set ws = ThisWorkbook.Worksheets("Suppliers")
            sid = CStr(ws.Cells(CLng(item(1)), 1).Value2)
            For r = FIRST To LASTS
                If CStr(ws.Cells(r, 1).Value2) = sid Then SetData ws.Cells(r, 2), item(3)
            Next r
        End If
        If item(0) = "Quotes" And item(2) = 4 Then
            cidRow = FindRow("Suppliers", 4, CStr(item(3)))
            If cidRow > 0 Then ThisWorkbook.Worksheets("Quotes").Cells(CLng(item(1)), 3).Value2 = ThisWorkbook.Worksheets("Suppliers").Cells(cidRow, 1).Value2
        End If
    Next item
End Sub

Private Sub CapturePagePlan(ByVal ws As Worksheet, ByVal target As Range, ByVal plan As Collection)
    Dim item As Variant, r As Long, qr As Long, cr As Long, row As Long, pair As Variant
    r = FindRow("Jobs", 1, CStr(ws.Range("AA2").Value2))
    qr = FindRow("Quotes", 1, CStr(ws.Range("AA3").Value2))
    If qr > 0 Then cr = FindRow("Suppliers", 4, CStr(ThisWorkbook.Worksheets("Quotes").Cells(qr, 4).Value2))
    For Each item In JobMap()
        If Not Intersect(target, ws.Range(CStr(item(0))).MergeArea) Is Nothing Then PutPlan plan, "Jobs", r, CLng(item(1)), ws.Range(CStr(item(0))).Value2
    Next item
    For Each item In ContactMap()
        If Not Intersect(target, ws.Range(CStr(item(0))).MergeArea) Is Nothing Then PutPlan plan, "Suppliers", cr, CLng(item(1)), ws.Range(CStr(item(0))).Value2
    Next item
    For Each item In QuoteMap()
        If Not Intersect(target, ws.Range(CStr(item(0))).MergeArea) Is Nothing Then PutPlan plan, "Quotes", qr, CLng(item(1)), ws.Range(CStr(item(0))).Value2
    Next item
    If Not Intersect(target, ws.Range("A64:V93")) Is Nothing Then
        For row = 64 To 93
            qr = CLng(Val(CStr(ws.Cells(row, 27).Value2)))
            If qr > 0 Then
                For Each pair In Array(Array("I", 6), Array("M", 7), Array("P", 8), Array("S", 9))
                    If Not Intersect(target, ws.Range(CStr(pair(0)) & row).MergeArea) Is Nothing Then PutPlan plan, "Quotes", qr + 8, CLng(pair(1)), ws.Range(CStr(pair(0)) & row).Value2
                Next pair
            End If
        Next row
    End If
End Sub

Private Function SourceEditable(ByVal sn As String, ByVal col As Long, ByVal row As Long) As Boolean
    Select Case sn
        Case "Jobs": SourceEditable = (row >= FIRST And row <= LASTQ And ((col >= 2 And col <= 4) Or (col >= 9 And col <= 14)))
        Case "Suppliers": SourceEditable = (row >= FIRST And row <= LASTS And (col = 2 Or col = 3 Or (col >= 5 And col <= 9)))
        Case "Quotes": SourceEditable = (row >= FIRST And row <= LASTQ And (col = 2 Or (col >= 4 And col <= 18)))
        Case "Vessel": SourceEditable = (col = 7 And row >= 8 And row <= 19)
        Case "Lists": SourceEditable = (col = 6 And row >= 9 And row <= 14)
    End Select
End Function

Public Sub HandleChange(ByVal sh As Object, ByVal target As Range)
    Dim plan As Collection, cell As Range, c As Long, r As Long, msg As String, qid As String
    Dim source As Boolean, item As Variant
    If mBusy Or Not mActive Then Exit Sub
    If TypeName(sh) <> "Worksheet" Then Exit Sub
    If Not sh.Parent Is ThisWorkbook Then Exit Sub
    On Error GoTo Failed
    mBusy = True
    Set plan = New Collection
    If sh.Name = "Add Supplier" Then
        If Not Intersect(target, sh.Range("D11,D13,D16")) Is Nothing Then PrefillForm sh, target
        GoTo Completed
    End If
    If sh.Name = "Create Job" Then GoTo Completed
    If sh.Name = "Supplier Jobs" Then
        If Not Intersect(target, sh.Range("B6")) Is Nothing Then ApplySupplierFilter: GoTo Completed
        For Each cell In target.Cells
            r = cell.Row: c = cell.Column
            If r >= FIRST And r <= LASTQ Then
                Select Case c
                    Case 4: PutPlan plan, "Quotes", FindRow("Quotes", 1, CStr(sh.Cells(r, 1).Value2)), 5, cell.Value2
                    Case 6: PutPlan plan, "Quotes", FindRow("Quotes", 1, CStr(sh.Cells(r, 1).Value2)), 6, cell.Value2
                    Case 7: PutPlan plan, "Quotes", FindRow("Quotes", 1, CStr(sh.Cells(r, 1).Value2)), 7, cell.Value2
                    Case 8: PutPlan plan, "Quotes", FindRow("Quotes", 1, CStr(sh.Cells(r, 1).Value2)), 8, cell.Value2
                    Case 9: PutPlan plan, "Quotes", FindRow("Quotes", 1, CStr(sh.Cells(r, 1).Value2)), 9, cell.Value2
                End Select
            End If
        Next cell
    ElseIf IsPage(sh) Then
        If Not IsEditor(sh) Then GoTo Completed
        If Not Intersect(target, sh.Range("P14").MergeArea) Is Nothing Then
            qid = ChoiceID(sh.Range("P14").Value2)
            r = FindRow("Quotes", 1, qid)
            If r = 0 Then
                If Len(qid) > 0 Then MsgBox "Choose an offer from this job's dropdown.", vbExclamation
            ElseIf CStr(ThisWorkbook.Worksheets("Quotes").Cells(r, 2).Value2) <> CStr(sh.Range("AA2").Value2) Then
                MsgBox "That offer belongs to another job.", vbExclamation
            Else
                sh.Range("AA3").Value2 = qid
            End If
            RefreshPage sh
            GoTo Completed
        End If
        CapturePagePlan sh, target, plan
    Else
        For Each cell In target.Cells
            If SourceEditable(sh.Name, cell.Column, cell.Row) Then
                If sh.Name = "Vessel" Or sh.Name = "Lists" Then
                    plan.Add Array(sh.Name, cell.Row, cell.Column, cell.Value2)
                Else
                    If Len(CStr(sh.Cells(cell.Row, 1).Value2)) = 0 Then Err.Raise vbObjectError + 223, , "Use Create Job or Add Supplier / Quote to create records."
                    PutPlan plan, sh.Name, cell.Row, cell.Column, cell.Value2
                End If
            End If
        Next cell
    End If
    If plan.Count = 0 Then GoTo Completed
    msg = ValidatePlan(plan)
    If Len(msg) > 0 Then Err.Raise vbObjectError + 224, , msg
    If Not ResolveSelections(plan) Then
        RollbackSources
        RefreshAll
        ConfigureEditors True
        GoTo Completed
    End If
    CommitPlan plan
    RefreshAll
    ConfigureEditors True
    SnapshotSources
Completed:
    Application.Calculate
    ConfigureEditors True
    mBusy = False
    Exit Sub
Failed:
    msg = Err.Description
    On Error Resume Next
    RollbackSources
    RefreshAll
    ConfigureEditors True
    On Error GoTo 0
    mBusy = False
    If Not mTesting Then MsgBox "Change was not accepted: " & msg & vbCrLf & "Previous central values have been restored.", vbExclamation
End Sub

Private Sub AddListName(ByVal name As String, ByVal area As String)
    On Error Resume Next
    ThisWorkbook.Names(name).Delete
    On Error GoTo 0
    ThisWorkbook.Names.Add Name:=name, RefersTo:="=" & area
End Sub

Private Sub AddValidation(ByVal cell As Range, ByVal listName As String)
    With cell.MergeArea.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=" & listName
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "Choose from the list"
        .ErrorMessage = "Use one of the shared dropdown values."
    End With
End Sub

Private Sub RebuildLists()
    Dim ls As Worksheet, ss As Worksheet, js As Worksheet, qs As Worksheet, ws As Worksheet
    Dim seen As Object, r As Long, sr As Long, cr As Long, jr As Long, col As Long, n As Long
    Dim sid As String, jid As String, qid As String, caption As String, listName As String
    Set ls = ThisWorkbook.Worksheets("_PilotLists")
    Set ss = ThisWorkbook.Worksheets("Suppliers"): Set js = ThisWorkbook.Worksheets("Jobs"): Set qs = ThisWorkbook.Worksheets("Quotes")
    ls.Cells.ClearContents
    ls.Range("A1:D1").Value = Array("Supplier", "Contact", "Job", "Supplier filter")
    ls.Range("D2").Value2 = "All suppliers"
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    sr = 2: cr = 2: jr = 2
    For r = FIRST To LASTS
        sid = CStr(ss.Cells(r, 1).Value2)
        If Len(sid) > 0 Then
            caption = sid & " | " & CStr(ss.Cells(r, 2).Value2)
            If Not seen.Exists(sid) Then
                seen.Add sid, True
                ls.Cells(sr, 1).Value2 = caption: ls.Cells(sr + 1, 4).Value2 = caption: sr = sr + 1
            End If
            ls.Cells(cr, 2).Value2 = CStr(ss.Cells(r, 4).Value2) & " | " & CStr(ss.Cells(r, 2).Value2) & " | " & CStr(ss.Cells(r, 5).Value2)
            cr = cr + 1
        End If
    Next r
    For r = FIRST To LASTQ
        If Len(CStr(js.Cells(r, 1).Value2)) > 0 Then
            ls.Cells(jr, 3).Value2 = CStr(js.Cells(r, 1).Value2) & " | " & CStr(js.Cells(r, 2).Value2)
            jr = jr + 1
        End If
    Next r
    AddListName "lstPilotSuppliers", "'_PilotLists'!$A$2:$A$" & Application.Max(2, sr - 1)
    AddListName "lstPilotContacts", "'_PilotLists'!$B$2:$B$" & Application.Max(2, cr - 1)
    AddListName "lstPilotJobs", "'_PilotLists'!$C$2:$C$" & Application.Max(2, jr - 1)
    AddListName "lstPilotSupplierFilter", "'_PilotLists'!$D$2:$D$" & sr
    AddListName "lstJobID", "'Jobs'!$A$9:$A$258"
    AddListName "lstSupplierID", "'Suppliers'!$A$9:$A$508"
    AddListName "lstContactID", "'Suppliers'!$D$9:$D$508"
    col = 5
    For Each ws In ThisWorkbook.Worksheets
        If IsPage(ws) Then
            ws.Unprotect PW
            jid = CStr(ws.Range("AA2").Value2): n = 2
            ls.Cells(1, col).Value2 = ws.Name
            For r = FIRST To LASTQ
                If CStr(qs.Cells(r, 2).Value2) = jid And Len(CStr(qs.Cells(r, 1).Value2)) > 0 Then
                    ls.Cells(n, col).Value2 = CStr(qs.Cells(r, 1).Value2) & " | " & CStr(qs.Cells(r, 21).Value2) & " | " & CStr(qs.Cells(r, 5).Value2)
                    n = n + 1
                End If
            Next r
            listName = "kpOffers_" & Format$(col, "0000")
            AddListName listName, "'_PilotLists'!" & ls.Range(ls.Cells(2, col), ls.Cells(Application.Max(2, n - 1), col)).Address
            ws.Range("AA8").Value2 = listName
            AddValidation ws.Range("P14"), listName
            col = col + 1
        End If
    Next ws
End Sub

Private Sub UpdateJobLinks()
    Dim ws As Worksheet, js As Worksheet, r As Long, seen As Object, jid As String
    Set js = ThisWorkbook.Worksheets("Jobs")
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    js.Unprotect PW
    js.Range("P9:P258").ClearContents
    For Each ws In ThisWorkbook.Worksheets
        If IsPage(ws) Then
            jid = CStr(ws.Range("AA2").Value2)
            If seen.Exists(jid) Then Err.Raise vbObjectError + 227, , "Duplicate job workspace for " & jid & ". Remove the duplicate in this test copy."
            seen.Add jid, True
            r = FindRow("Jobs", 1, jid)
            If r > 0 Then js.Cells(r, 16).Value2 = ws.Name
        End If
    Next ws
End Sub

Private Sub SetExternalLink(ByVal cell As Range, ByVal address As String)
    Dim old As String
    If cell.Hyperlinks.Count > 0 Then old = cell.Hyperlinks(1).Address
    If old = address Then Exit Sub
    If cell.Hyperlinks.Count > 0 Then cell.Hyperlinks.Delete
    If Len(Trim$(address)) > 0 Then cell.Parent.Hyperlinks.Add Anchor:=cell, Address:=address
End Sub

Private Sub SetInternalLink(ByVal cell As Range, ByVal targetSheet As String, ByVal targetCell As String, Optional ByVal caption As String = "")
    If cell.Hyperlinks.Count > 0 Then cell.Hyperlinks.Delete
    If Len(caption) > 0 Then cell.Value2 = caption
    cell.Parent.Hyperlinks.Add Anchor:=cell, Address:="", SubAddress:="'" & Replace(targetSheet, "'", "''") & "'!" & targetCell
End Sub

Private Sub RefreshPage(ByVal ws As Worksheet)
    Dim t As Worksheet, item As Variant, qr As Long, cr As Long, jr As Long, r As Long, pair As Variant
    Dim jid As String, qid As String, firstQuote As String, n As Long, qs As Worksheet
    Set t = ThisWorkbook.Worksheets("_JobTemplate"): Set qs = ThisWorkbook.Worksheets("Quotes")
    ws.Unprotect PW
    jid = CStr(ws.Range("AA2").Value2): qid = CStr(ws.Range("AA3").Value2)
    qr = FindRow("Quotes", 1, qid)
    If qr > 0 Then
        If CStr(qs.Cells(qr, 2).Value2) <> jid Then qr = 0
    End If
    For r = FIRST To LASTQ
        If CStr(qs.Cells(r, 2).Value2) = jid And Len(CStr(qs.Cells(r, 1).Value2)) > 0 Then
            n = n + 1
            If Len(firstQuote) = 0 Then firstQuote = CStr(qs.Cells(r, 1).Value2)
        End If
    Next r
    If qr = 0 Then qid = firstQuote: qr = FindRow("Quotes", 1, qid)
    ws.Range("AA3").Value2 = qid
    If qr > 0 Then
        ws.Range("P14").Value2 = qid & " | " & CStr(qs.Cells(qr, 21).Value2) & " | " & CStr(qs.Cells(qr, 5).Value2)
    Else
        ws.Range("P14").ClearContents
    End If
    For Each item In JobMap(): ws.Range(CStr(item(0))).Formula = t.Range(CStr(item(0))).Formula: Next item
    For Each item In ContactMap(): ws.Range(CStr(item(0))).Formula = t.Range(CStr(item(0))).Formula: Next item
    For Each item In QuoteMap(): ws.Range(CStr(item(0))).Formula = t.Range(CStr(item(0))).Formula: Next item
    For r = 64 To 93
        For Each pair In Array("I", "M", "P", "S")
            ws.Range(CStr(pair) & r).Formula = t.Range(CStr(pair) & r).Formula
        Next pair
        ws.Rows(r).Hidden = (r - 63 > Application.Max(3, n))
    Next r
    If qr > 0 Then
        SetExternalLink ws.Range("M42"), CStr(qs.Cells(qr, 14).Value2)
        SetExternalLink ws.Range("M46"), CStr(qs.Cells(qr, 15).Value2)
    Else
        SetExternalLink ws.Range("M42"), ""
        SetExternalLink ws.Range("M46"), ""
    End If
    jr = FindRow("Jobs", 1, jid)
    If jr > 0 Then SetExternalLink ws.Range("A53"), CStr(ThisWorkbook.Worksheets("Jobs").Cells(jr, 14).Value2)
    ws.PageSetup.PrintArea = "$A$1:$V$" & (63 + Application.Max(3, Application.Min(30, n)))
End Sub

Private Sub RefreshSupplierJobs()
    Dim ws As Worksheet, r As Long, pair As Variant, sourceCol As String
    Set ws = ThisWorkbook.Worksheets("Supplier Jobs")
    ws.Unprotect PW
    For r = FIRST To LASTQ
        For Each pair In Array(Array("D", "E"), Array("F", "F"), Array("G", "G"), Array("H", "H"), Array("I", "I"))
            sourceCol = CStr(pair(1))
            ws.Range(CStr(pair(0)) & r).Formula = "=IF(Quotes!$A" & r & "="""","""",IF(Quotes!" & sourceCol & r & "="""","""",Quotes!" & sourceCol & r & "))"
        Next pair
    Next r
End Sub

Private Sub RefreshDocumentLinks()
    Dim qs As Worksheet, ss As Worksheet, ps As Worksheet, r As Long, n As Long, rr As Long, page As Long, slot As Long
    Set qs = ThisWorkbook.Worksheets("Quotes"): Set ss = ThisWorkbook.Worksheets("Suppliers"): Set ps = ThisWorkbook.Worksheets("Print Summary")
    qs.Unprotect PW: ss.Unprotect PW: ps.Unprotect PW
    For r = FIRST To LASTQ
        If Len(CStr(qs.Cells(r, 1).Value2)) > 0 Then
            SetExternalLink qs.Cells(r, 14), CStr(qs.Cells(r, 14).Value2)
            SetExternalLink qs.Cells(r, 15), CStr(qs.Cells(r, 15).Value2)
            qs.Cells(r, 43).Value2 = IIf(Len(CStr(qs.Cells(r, 14).Value2)) > 0, "Open original", "")
            qs.Cells(r, 44).Value2 = IIf(Len(CStr(qs.Cells(r, 15).Value2)) > 0, "Open revised", "")
            SetExternalLink qs.Cells(r, 43), CStr(qs.Cells(r, 14).Value2)
            SetExternalLink qs.Cells(r, 44), CStr(qs.Cells(r, 15).Value2)
        End If
    Next r
    For r = FIRST To LASTS
        If Len(CStr(ss.Cells(r, 1).Value2)) > 0 Then SetInternalLink ss.Cells(r, 10), "Supplier Jobs", "A1", "Jobs / quotes"
    Next r
    n = 0
    For r = FIRST To LASTQ
        If CStr(qs.Cells(r, 6).Value2) = "Selected" And Len(CStr(qs.Cells(r, 1).Value2)) > 0 Then
            n = n + 1: page = (n - 1) \ 4: slot = (n - 1) Mod 4
            rr = 40 + page * 38 + slot * 9
            SetExternalLink ps.Range("A" & rr + 5), CStr(qs.Cells(r, 14).Value2)
            SetExternalLink ps.Range("I" & rr + 5), CStr(qs.Cells(r, 15).Value2)
        End If
    Next r
    For r = n + 1 To 250
        page = (r - 1) \ 4: slot = (r - 1) Mod 4: rr = 40 + page * 38 + slot * 9
        SetExternalLink ps.Range("A" & rr + 5), ""
        SetExternalLink ps.Range("I" & rr + 5), ""
    Next r
End Sub

Private Sub RefreshPrintAreas()
    Dim n As Long, ws As Worksheet, last As Long
    n = CLng(Val(CStr(ThisWorkbook.Worksheets("_Control").Range("B15").Value2)))
    Set ws = ThisWorkbook.Worksheets("Overview"): ws.Unprotect PW
    ws.Rows("18:267").Hidden = True
    If n > 0 Then ws.Rows("18:" & 17 + n).Hidden = False
    ws.PageSetup.PrintArea = "$A$1:$V$" & Application.Max(18, 17 + n)
    n = CLng(Val(CStr(ThisWorkbook.Worksheets("_Control").Range("B17").Value2)))
    Set ws = ThisWorkbook.Worksheets("Negotiation Savings"): ws.Unprotect PW
    ws.Rows("18:267").Hidden = True
    If n > 0 Then ws.Rows("18:" & 17 + n).Hidden = False
    ws.PageSetup.PrintArea = "$A$1:$V$" & Application.Max(18, 17 + n)
    n = CLng(Val(CStr(ThisWorkbook.Worksheets("_Control").Range("B12").Value2)))
    last = 38 + 38 * ((n + 3) \ 4)
    Set ws = ThisWorkbook.Worksheets("Print Summary"): ws.Unprotect PW
    ws.Rows("39:2432").Hidden = True
    If last > 38 Then ws.Rows("39:" & last).Hidden = False
    ws.PageSetup.PrintArea = "$A$1:$V$" & last
End Sub

Private Sub RefreshAll()
    Dim ws As Worksheet
    UpdateJobLinks
    Application.Calculate
    RebuildLists
    RefreshSupplierJobs
    For Each ws In ThisWorkbook.Worksheets
        If IsPage(ws) Then RefreshPage ws
    Next ws
    Application.Calculate
    RefreshDocumentLinks
    ApplyJobView
    RefreshPrintAreas
    ThisWorkbook.Worksheets("_PilotState").Range("B3").Value2 = Now
End Sub

Private Sub UnlockCell(ByVal ws As Worksheet, ByVal address As String, ByVal active As Boolean)
    ws.Range(address).MergeArea.Locked = Not active
End Sub

Private Sub ConfigureEditors(ByVal active As Boolean)
    Dim ws As Worksheet, item As Variant, r As Long, col As Variant, addr As Variant
    For Each ws In ThisWorkbook.Worksheets
        If ws.Visible = xlSheetVisible Then
            ws.Unprotect PW
            If IsPage(ws) Then
                ws.UsedRange.Locked = True
                If IsEditor(ws) And active Then
                    UnlockCell ws, "P14", True
                    For Each item In JobMap(): UnlockCell ws, CStr(item(0)), True: Next item
                    If Val(CStr(ws.Range("AA6").Value2)) > 0 Then
                        For Each item In ContactMap(): UnlockCell ws, CStr(item(0)), True: Next item
                        For Each item In QuoteMap(): UnlockCell ws, CStr(item(0)), True: Next item
                    End If
                    For r = 64 To 93
                        If Val(CStr(ws.Cells(r, 27).Value2)) > 0 Then
                            For Each col In Array("I", "M", "P", "S"): UnlockCell ws, CStr(col) & r, True: Next col
                        End If
                    Next r
                    ws.Range("S6").Value2 = "PILOT ACTIVE"
                ElseIf IsEditor(ws) Then
                    ws.Range("S6").Value2 = "PILOT - RUN StartPilot"
                Else
                    ws.Range("S6").Value2 = "LINKED REPORT"
                End If
            ElseIf ws.Name = "Supplier Jobs" Then
                ws.UsedRange.Locked = True
                ws.Range("D9:D258,F9:I258").Locked = Not active
                UnlockCell ws, "B6", active
            ElseIf ws.Name = "Create Job" Then
                ws.UsedRange.Locked = True: UnlockCell ws, "E11", active
            ElseIf ws.Name = "Add Supplier" Then
                ws.UsedRange.Locked = True
                For Each addr In Array("D11", "D13", "D16", "D20", "D23", "D26", "D28", "D31", "D33", "A37", "P11", "P14", "P16", "P18", "P20", "P23", "P27", "P29", "P31", "M35", "M40", "A45", "M45")
                    UnlockCell ws, CStr(addr), active
                Next addr
                If active Then
                    If CStr(ws.Range("D11").Value2) = "Existing contact" Then
                        For Each addr In Array("D13", "D20", "D23", "D26", "D28", "D31", "D33", "A37")
                            UnlockCell ws, CStr(addr), False
                        Next addr
                    ElseIf CStr(ws.Range("D11").Value2) = "New contact" Then
                        UnlockCell ws, "D16", False
                        UnlockCell ws, "D20", False
                    Else
                        UnlockCell ws, "D13", False
                        UnlockCell ws, "D16", False
                    End If
                End If
            End If
            ws.Protect Password:=PW, UserInterfaceOnly:=True, AllowFiltering:=True
            ws.EnableSelection = xlNoRestrictions
        End If
    Next ws
End Sub

Private Sub Button(ByVal ws As Worksheet, ByVal area As String, ByVal name As String, ByVal caption As String, ByVal macro As String)
    Dim rg As Range, sp As Shape
    ws.Unprotect PW
    On Error Resume Next
    ws.Shapes(name).Delete
    On Error GoTo 0
    Set rg = ws.Range(area)
    Set sp = ws.Shapes.AddShape(msoShapeRoundedRectangle, rg.Left + 1, rg.Top + 1, rg.Width - 2, rg.Height - 2)
    sp.Name = name
    sp.Fill.ForeColor.RGB = RGB(8, 127, 140)
    sp.Line.Visible = msoFalse
    sp.TextFrame2.TextRange.Text = caption
    With sp.TextFrame2
        .VerticalAnchor = msoAnchorMiddle
        .MarginLeft = 8: .MarginRight = 8: .MarginTop = 2: .MarginBottom = 2
        .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .TextRange.Font.Name = "Aptos"
        .TextRange.Font.Size = 11
        .TextRange.Font.Bold = msoTrue
        .TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
    End With
    sp.Placement = xlFreeFloating
    sp.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macro
    sp.AlternativeText = caption & " - controlled KERRY pilot"
End Sub

Private Sub InstallControls(ByVal ws As Worksheet)
    If ws.Visible <> xlSheetVisible Then Exit Sub
    If IsEditor(ws) Then
        Button ws, "A6:F6", "kp_AddQuote", "+ ADD SUPPLIER / QUOTE", "OpenAddSupplier"
    ElseIf ws.Name = "Jobs" Then
        Button ws, "D6:H6", "kp_JobView", "SHOW ALL / ACTIVE JOBS", "ToggleJobView"
    ElseIf ws.Name = "Create Job" Then
        Button ws, "A23:J25", "kp_CreateJob", "CREATE / OPEN JOB", "CreateJob"
    ElseIf ws.Name = "Add Supplier" Then
        Button ws, "A52:K54", "kp_SaveQuote", "SAVE SUPPLIER / QUOTE", "SaveSupplierQuote"
    ElseIf ws.Name = "Test Results" Then
        Button ws, "H6:M6", "kp_RunChecks", "RUN PILOT CHECKS", "RunPilotChecks"
    End If
End Sub

Public Sub CreateJob()
    Dim jid As String, jr As Long, ws As Worksheet, template As Worksheet, name As String, suffix As Long, msg As String, baseName As String, created As Boolean, started As Boolean
    If Not mActive Or mBusy Then Exit Sub
    On Error GoTo Failed
    jid = ChoiceID(ThisWorkbook.Worksheets("Create Job").Range("E11").Value2)
    jr = FindRow("Jobs", 1, jid)
    If jr = 0 Then MsgBox "Choose a job from the shared catalogue first.", vbExclamation: Exit Sub
    Set ws = PageForJob(jid)
    If Not ws Is Nothing Then
        ws.Activate
        If Not IsEditor(ws) Then MsgBox "This existing page is a linked report in the pilot. JOB 3103.01 and new pages created by the pilot are the editable test pages.", vbInformation
        Exit Sub
    End If
    mBusy = True: started = True
    SnapshotSources
    Set template = ThisWorkbook.Worksheets("_JobTemplate")
    template.Copy After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count)
    Set ws = ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count)
    created = True
    name = "JOB " & jid
    name = Replace(Replace(Replace(Replace(Replace(Replace(Replace(name, "/", "-"), Chr$(92), "-"), "[", "("), "]", ")"), ":", "-"), "?", ""), "*", "")
    name = Left$(name, 31): baseName = name
    Do While HasSheet(name)
        suffix = suffix + 1: name = Left$(baseName, 26) & "-" & suffix
    Loop
    ws.Name = name: ws.Visible = xlSheetVisible: ws.Unprotect PW
    ws.Range("AA2").Value2 = jid: ws.Range("AA3").ClearContents: ws.Range("AA4").Value2 = "EDITABLE"
    ws.Range("A1").Value2 = "Job workspace / " & jid
    InstallControls ws
    RefreshAll
    ConfigureEditors True
    SnapshotSources
    ws.Activate
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 90
    mBusy = False
    Exit Sub
Failed:
    msg = Err.Description
    On Error Resume Next
    If started Then RollbackSources
    If created Then
        ' Retain an incomplete copy without treating it as a live job page.
        ws.Unprotect PW
        ws.Range("AA1").Value2 = "KERRY_INCOMPLETE_JOB"
        ThisWorkbook.Worksheets("Create Job").Activate
        ws.Visible = xlSheetVeryHidden
    End If
    RefreshAll
    ConfigureEditors True
    On Error GoTo 0
    mBusy = False
    MsgBox "Job creation stopped: " & msg & vbCrLf & "No original job data was deleted.", vbExclamation
End Sub

Public Sub OpenAddSupplier()
    Dim ws As Worksheet, form As Worksheet, addr As Variant
    If Not mActive Or mBusy Then Exit Sub
    If Not IsEditor(ActiveSheet) Then MsgBox "Open the editable pilot job or a newly created job first.", vbInformation: Exit Sub
    On Error GoTo Failed
    mBusy = True
    Set ws = ActiveSheet: Set form = ThisWorkbook.Worksheets("Add Supplier")
    form.Unprotect PW
    For Each addr In Array("D13", "D16", "D20", "D23", "D26", "D28", "D31", "D33", "A37", "P18", "P20", "P23", "P27", "P29", "P31", "M35", "M40", "A45", "M45")
        form.Range(CStr(addr)).MergeArea.ClearContents
    Next addr
    form.Range("D11").Value2 = "Existing contact"
    form.Range("P11").Value2 = "Main scope": form.Range("P14").Value2 = "RFQ sent": form.Range("P16").Value2 = "EUR"
    form.Range("AA2").Value2 = ws.Range("AA2").Value2: form.Range("AA3").Value2 = ws.Name
    form.Range("M6").Value2 = ws.Range("AA2").Value2
    SetInternalLink form.Range("A6"), ws.Name, "A1", "BACK TO JOB"
    ConfigureEditors True
    form.Activate
    mBusy = False
    Exit Sub
Failed:
    mBusy = False
    MsgBox "Could not open the draft form: " & Err.Description, vbExclamation
End Sub

Private Sub PrefillForm(ByVal form As Worksheet, ByVal changed As Range)
    Dim mode As String, r As Long, sid As String, ss As Worksheet, addr As Variant
    form.Unprotect PW
    mode = CStr(form.Range("D11").Value2)
    If Not Allowed(mode, "lstPilotModes", False) Then form.Range("D11").Value2 = "Existing contact": mode = "Existing contact"
    Set ss = ThisWorkbook.Worksheets("Suppliers")
    If Not Intersect(changed, form.Range("D11")) Is Nothing Then
        For Each addr In Array("D13", "D16", "D20", "D23", "D26", "D28", "D31", "D33", "A37"): form.Range(CStr(addr)).MergeArea.ClearContents: Next addr
    End If
    If mode = "Existing contact" Then
        r = FindRow("Suppliers", 4, ChoiceID(form.Range("D16").Value2))
        If r > 0 Then
            sid = CStr(ss.Cells(r, 1).Value2)
            form.Range("D13").Value2 = sid & " | " & ss.Cells(r, 2).Value2
            form.Range("D20").Value2 = ss.Cells(r, 2).Value2
            form.Range("D23").Value2 = ss.Cells(r, 3).Value2
            form.Range("D26").Value2 = ss.Cells(r, 5).Value2
            form.Range("D28").Value2 = ss.Cells(r, 6).Value2
            form.Range("D31").Value2 = ss.Cells(r, 7).Value2
            form.Range("D33").Value2 = ss.Cells(r, 8).Value2
            form.Range("A37").Value2 = ss.Cells(r, 9).Value2
        End If
    ElseIf mode = "New contact" Then
        r = FindRow("Suppliers", 1, ChoiceID(form.Range("D13").Value2))
        If r > 0 Then form.Range("D20").Value2 = ss.Cells(r, 2).Value2
    End If
    form.Protect Password:=PW, UserInterfaceOnly:=True, AllowFiltering:=True
End Sub

Private Function FreeRow(ByVal sn As String) As Long
    Dim r As Long, last As Long
    last = LASTQ: If sn = "Suppliers" Then last = LASTS
    For r = FIRST To last
        If Len(CStr(ThisWorkbook.Worksheets(sn).Cells(r, 1).Value2)) = 0 Then FreeRow = r: Exit Function
    Next r
End Function

Private Function NewID(ByVal sn As String, ByVal col As Long, ByVal prefix As String, ByVal digits As Long) As String
    Dim n As Long, id As String
    n = 1
    Do
        id = prefix & Format$(n, String$(digits, "0"))
        If FindRow(sn, col, id) = 0 Then NewID = id: Exit Function
        n = n + 1
        If n > 100000 Then Err.Raise vbObjectError + 229, , "ID capacity exceeded."
    Loop
End Function

Public Sub SaveSupplierQuote()
    Dim form As Worksheet, ss As Worksheet, qs As Worksheet, ws As Worksheet
    Dim mode As String, jid As String, sid As String, cid As String, qid As String, company As String, email As String
    Dim sr As Long, qr As Long, r As Long, jr As Long, newContact As Boolean, plan As Collection, msg As String, pair As Variant
    If Not mActive Or mBusy Then Exit Sub
    On Error GoTo Failed
    Set form = ThisWorkbook.Worksheets("Add Supplier"): Set ss = ThisWorkbook.Worksheets("Suppliers"): Set qs = ThisWorkbook.Worksheets("Quotes")
    jid = CStr(form.Range("AA2").Value2): jr = FindRow("Jobs", 1, jid): Set ws = PageForJob(jid)
    If jr = 0 Or ws Is Nothing Then MsgBox "Open this draft form from a created job.", vbExclamation: Exit Sub
    If Not IsEditor(ws) Then MsgBox "This job is a read-only report in the pilot.", vbExclamation: Exit Sub
    If Application.CountIf(qs.Range("B9:B258"), jid) >= 30 Then MsgBox "Pilot limit: 30 offers per job. No data was added.", vbExclamation: Exit Sub
    qr = FreeRow("Quotes")
    If qr = 0 Then MsgBox "The 250-offer pilot capacity is full. No data was added.", vbExclamation: Exit Sub
    mode = CStr(form.Range("D11").Value2)
    If Not Allowed(mode, "lstPilotModes", False) Then MsgBox "Choose an entry mode.", vbExclamation: Exit Sub
    If mode = "Existing contact" Then
        cid = ChoiceID(form.Range("D16").Value2): sr = FindRow("Suppliers", 4, cid)
        If sr = 0 Then MsgBox "Choose an existing contact.", vbExclamation: Exit Sub
        sid = CStr(ss.Cells(sr, 1).Value2)
    Else
        newContact = True: sr = FreeRow("Suppliers")
        If sr = 0 Then MsgBox "The 500-contact pilot capacity is full.", vbExclamation: Exit Sub
        If mode = "New contact" Then
            sid = ChoiceID(form.Range("D13").Value2): r = FindRow("Suppliers", 1, sid)
            If r = 0 Then MsgBox "Choose the existing supplier for this new contact.", vbExclamation: Exit Sub
            company = CStr(ss.Cells(r, 2).Value2)
        Else
            company = Trim$(CStr(form.Range("D20").Value2))
            If Len(company) = 0 Then MsgBox "Enter the company name.", vbExclamation: Exit Sub
            For r = FIRST To LASTS
                If Len(CStr(ss.Cells(r, 1).Value2)) > 0 And Trim$(CStr(ss.Cells(r, 2).Value2)) = company Then
                    MsgBox "This company already exists as " & ss.Cells(r, 1).Value2 & ". Use Existing contact or New contact rather than create a duplicate supplier.", vbExclamation
                    Exit Sub
                End If
            Next r
            sid = NewID("Suppliers", 1, "SUP-", 5)
        End If
        If Len(Trim$(CStr(form.Range("D26").Value2))) = 0 And Len(Trim$(CStr(form.Range("D28").Value2))) = 0 Then MsgBox "Enter at least a contact name or email address.", vbExclamation: Exit Sub
        cid = NewID("Suppliers", 4, "CT", 5)
    End If
    If Not Allowed(form.Range("P14").Value2, "lstQuoteStatus", False) Then MsgBox "Choose a quote status.", vbExclamation: Exit Sub
    If Not Allowed(form.Range("P16").Value2, "lstCurrency", False) Then MsgBox "Choose a currency.", vbExclamation: Exit Sub
    If Not ValidMoney(form.Range("P18").Value2) Or Not ValidMoney(form.Range("P20").Value2) Then MsgBox "Enter numeric, non-negative prices or leave them empty.", vbExclamation: Exit Sub
    If Len(Trim$(CStr(form.Range("P11").Value2))) = 0 Then MsgBox "Enter the scope / package.", vbExclamation: Exit Sub
    For Each pair In Array("P27", "P29", "P31")
        If Not ValidDate(form.Range(CStr(pair)).Value2) Then MsgBox "One of the quote dates is invalid.", vbExclamation: Exit Sub
    Next pair
    mBusy = True
    SnapshotSources
    ss.Unprotect PW: qs.Unprotect PW
    If newContact Then
        ss.Cells(sr, 1).Value2 = sid: ss.Cells(sr, 2).Value2 = company: ss.Cells(sr, 4).Value2 = cid
        For Each pair In Array(Array("D23", 3), Array("D26", 5), Array("D28", 6), Array("D31", 7), Array("D33", 8), Array("A37", 9))
            SetData ss.Cells(sr, CLng(pair(1))), form.Range(CStr(pair(0))).Value2
        Next pair
    End If
    qid = NewID("Quotes", 1, jid & "-Q", 1)
    qs.Cells(qr, 1).Value2 = qid: qs.Cells(qr, 2).Value2 = jid: qs.Cells(qr, 3).Value2 = sid: qs.Cells(qr, 4).Value2 = cid
    Set plan = New Collection
    For Each pair In Array(Array("P11", 5), Array("P14", 6), Array("P18", 7), Array("P20", 8), Array("P16", 9), Array("P27", 10), Array("P29", 11), Array("P31", 12), Array("P23", 13), Array("M35", 14), Array("M40", 15), Array("A45", 16), Array("M45", 17))
        PutPlan plan, "Quotes", qr, CLng(pair(1)), form.Range(CStr(pair(0))).Value2
    Next pair
    msg = ValidatePlan(plan)
    If Len(msg) > 0 Then Err.Raise vbObjectError + 230, , msg
    If Not ResolveSelections(plan) Then RollbackSources: GoTo Cancelled
    CommitPlan plan
    ws.Unprotect PW: ws.Range("AA3").Value2 = qid
    RefreshAll
    ConfigureEditors True
    SnapshotSources
    ws.Activate
    mBusy = False
    MsgBox "Offer " & qid & " was added. Contact and supplier IDs were " & IIf(newContact, "created", "reused") & ".", vbInformation
    Exit Sub
Cancelled:
    RefreshAll
    ConfigureEditors True
    mBusy = False
    Exit Sub
Failed:
    msg = Err.Description
    On Error Resume Next
    RollbackSources
    RefreshAll
    ConfigureEditors True
    On Error GoTo 0
    mBusy = False
    MsgBox "Nothing was added: " & msg, vbExclamation
End Sub


Private Sub ApplyJobView()
    Dim ws As Worksheet, mode As String
    Set ws = ThisWorkbook.Worksheets("Jobs")
    mode = CStr(ThisWorkbook.Worksheets("_PilotState").Range("B6").Value2)
    ws.Unprotect PW
    If ws.FilterMode Then ws.ShowAllData
    ws.Rows("9:258").Hidden = False
    If mode <> "ALL" Then
        ws.ListObjects("tJobs").Range.AutoFilter Field:=16, Criteria1:="<>"
        ws.ListObjects("tJobs").Range.AutoFilter Field:=4, Criteria1:="<>Closed", Operator:=xlAnd, Criteria2:="<>Cancelled"
    End If
End Sub

Public Sub ToggleJobView()
    If Not mActive Or mBusy Then Exit Sub
    On Error GoTo Finished
    mBusy = True
    With ThisWorkbook.Worksheets("_PilotState").Range("B6")
        If CStr(.Value2) = "ALL" Then .Value2 = "ACTIVE" Else .Value2 = "ALL"
    End With
    ApplyJobView
    ConfigureEditors True
Finished:
    mBusy = False
End Sub

Private Sub ApplySupplierFilter()
    Dim ws As Worksheet, id As String
    Set ws = ThisWorkbook.Worksheets("Supplier Jobs"): ws.Unprotect PW
    id = ChoiceID(ws.Range("B6").Value2)
    If ws.FilterMode Then ws.ShowAllData
    If Len(id) > 0 And id <> "All suppliers" Then
        ws.Range("A8:N258").AutoFilter Field:=14, Criteria1:=id
    End If
    ws.Protect Password:=PW, UserInterfaceOnly:=True, AllowFiltering:=True
End Sub

Public Sub HandleFollowLink(ByVal sh As Object, ByVal target As Hyperlink)
    Dim r As Long, sid As String, ws As Worksheet
    If mBusy Or Not mActive Then Exit Sub
    If sh.Name <> "Suppliers" Then Exit Sub
    On Error GoTo Finished
    r = target.Range.Row
    If r < FIRST Or r > LASTS Then Exit Sub
    If target.Range.Column <> 10 Then Exit Sub
    mBusy = True
    sid = CStr(sh.Cells(r, 1).Value2)
    Set ws = ThisWorkbook.Worksheets("Supplier Jobs")
    ws.Unprotect PW
    ws.Range("B6").Value2 = sid & " | " & CStr(sh.Cells(r, 2).Value2)
    ApplySupplierFilter
Finished:
    mBusy = False
End Sub

Public Sub HandleActivate(ByVal sh As Object)
    If mBusy Or Not mActive Then Exit Sub
    If TypeName(sh) <> "Worksheet" Then Exit Sub
    On Error GoTo Finished
    mBusy = True
    ' Detect manual sheet renames/deletions before displaying navigation.
    UpdateJobLinks
    If IsPage(sh) Then RefreshPage sh
    Application.Calculate
    ConfigureEditors True
Finished:
    mBusy = False
End Sub

Public Sub BeforeWorkbookSave(ByRef cancel As Boolean)
    Dim msg As String
    If mBusy Or Not mActive Then Exit Sub
    On Error GoTo Failed
    mBusy = True
    RefreshAll
    ConfigureEditors False
    ThisWorkbook.Worksheets("_PilotState").Range("B2").Value2 = "NOT ACTIVE"
    mSaving = True
    mBusy = False
    Exit Sub
Failed:
    msg = Err.Description: cancel = True
    mBusy = False
    MsgBox "Save cancelled to avoid an inconsistent pilot: " & msg, vbCritical
End Sub

Public Sub AfterWorkbookSave(ByVal success As Boolean)
    If Not mSaving Then Exit Sub
    On Error GoTo Finished
    mBusy = True
    ConfigureEditors mActive
    ThisWorkbook.Worksheets("_PilotState").Range("B2").Value2 = IIf(mActive, "ACTIVE", "NOT ACTIVE")
    ' Only transient editor-lock/banner changes occur after the actual save.
    If success Then ThisWorkbook.Saved = True
Finished:
    mSaving = False: mBusy = False
End Sub

Private Sub TestRow(ByVal row As Long, ByVal caption As String, ByVal ok As Boolean)
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets("Test Results"): ws.Unprotect PW
    ws.Cells(row, 1).Value2 = row - 15
    ws.Cells(row, 3).Value2 = caption
    ws.Cells(row, 17).Value2 = IIf(ok, "PASS", "FAIL")
    ws.Cells(row, 17).Font.Color = IIf(ok, RGB(22, 112, 94), RGB(171, 58, 66))
End Sub

Public Sub RunPilotChecks()
    Dim ws As Worksheet, qs As Worksheet, ss As Worksheet, ctrl As Worksheet, tr As Worksheet
    Dim qr As Long, cr As Long, oldFinal As Variant, oldOriginal As Variant, oldStatus As Variant, oldCurrency As Variant, oldPhone As Variant, oldScope As Variant
    Dim oldPick As Variant, oldQID As Variant, jobID As String, msg As String, r As Long, baseline As Double, restored As Boolean, failed As Long
    If Not mActive Or mBusy Then MsgBox "Run StartPilot first.", vbInformation: Exit Sub
    If MsgBox("Run temporary price/status/contact checks in this TEST COPY? Values are restored at the end. Keep other editors out of this workbook.", vbOKCancel + vbQuestion) <> vbOK Then Exit Sub
    On Error GoTo Failed
    Set ws = ThisWorkbook.Worksheets("JOB 3103.01"): Set qs = ThisWorkbook.Worksheets("Quotes"): Set ss = ThisWorkbook.Worksheets("Suppliers")
    Set ctrl = ThisWorkbook.Worksheets("_Control"): Set tr = ThisWorkbook.Worksheets("Test Results")
    qr = FindRow("Quotes", 1, "3103.01-Q1")
    If qr = 0 Then Err.Raise vbObjectError + 235, , "The prepared test offer no longer exists."
    cr = FindRow("Suppliers", 4, CStr(qs.Cells(qr, 4).Value2))
    oldFinal = qs.Cells(qr, 8).Value2: oldOriginal = qs.Cells(qr, 7).Value2: oldStatus = qs.Cells(qr, 6).Value2: oldCurrency = qs.Cells(qr, 9).Value2
    oldPhone = ss.Cells(cr, 7).Value2: oldScope = qs.Cells(qr, 5).Value2
    oldPick = ws.Range("P14").Value2: oldQID = ws.Range("AA3").Value2
    mTesting = True: mBusy = True
    ws.Unprotect PW: ws.Range("AA3").Value2 = "3103.01-Q1"
    qs.Unprotect PW
    qs.Cells(qr, 5).Value2 = "__PILOT_TEST_SCOPE__"
    qs.Cells(qr, 6).Value2 = "Selected": qs.Cells(qr, 7).Value2 = 44800#: qs.Cells(qr, 8).ClearContents: qs.Cells(qr, 9).Value2 = "EUR"
    RefreshAll: ConfigureEditors True: SnapshotSources
    baseline = CDbl(ctrl.Range("B8").Value2)
    tr.Unprotect PW
    tr.Range("A16:V40").ClearContents
    mBusy = False
    ws.Range("P31").Value2 = 40000#
    Application.Calculate
    TestRow 16, "Job final price writes to Quotes", Abs(CDbl(qs.Cells(qr, 8).Value2) - 40000#) < 0.01
    TestRow 17, "Offer saving = 4,800 EUR", Abs(CDbl(qs.Cells(qr, 32).Value2) - 4800#) < 0.01
    TestRow 18, "Budget selected cost falls by 4,800 EUR", Abs(CDbl(ctrl.Range("B8").Value2) - (baseline - 4800#)) < 0.01
    TestRow 19, "Remaining budget rises by 4,800 EUR", Abs(CDbl(ctrl.Range("B10").Value2) - (CDbl(ctrl.Range("B6").Value2) - baseline + 4800#)) < 0.01
    qs.Cells(qr, 8).Value2 = 39000#
    Application.Calculate
    TestRow 20, "Quotes edits return to the job page", Abs(CDbl(ws.Range("P31").Value2) - 39000#) < 0.01
    ThisWorkbook.Worksheets("Supplier Jobs").Cells(qr, 8).Value2 = 38000#
    Application.Calculate
    TestRow 21, "Supplier Jobs price edits use the same QuoteID", Abs(CDbl(ws.Range("P31").Value2) - 38000#) < 0.01
    ws.Range("P31").MergeArea.ClearContents
    Application.Calculate
    TestRow 22, "Empty final price keeps original with no saving", Abs(CDbl(qs.Cells(qr, 30).Value2) - 44800#) < 0.01 And Len(CStr(qs.Cells(qr, 32).Value2)) = 0
    ws.Range("P31").Value2 = 0#
    Application.Calculate
    TestRow 23, "A numeric zero is a valid final price", Abs(CDbl(qs.Cells(qr, 32).Value2) - 44800#) < 0.01
    ws.Range("P31").Value2 = 46000#
    Application.Calculate
    TestRow 24, "Price increases produce a negative saving", Abs(CDbl(qs.Cells(qr, 32).Value2) + 1200#) < 0.01
    ws.Range("P31").Value2 = -1#
    Application.Calculate
    TestRow 25, "Invalid negative price is rejected and restored", Abs(CDbl(qs.Cells(qr, 8).Value2) - 46000#) < 0.01
    ws.Range("P29").Value2 = "NOK"
    Application.Calculate
    TestRow 26, "FX conversion follows the shared saved rate", Abs(CDbl(qs.Cells(qr, 30).Value2) - 46000# / RateFor("NOK")) < 0.01
    ws.Range("P29").Value2 = "EUR"
    ws.Range("P28").Value2 = "Quote received"
    Application.Calculate
    TestRow 27, "Unselected offer is excluded from budget", Abs(CDbl(ctrl.Range("B8").Value2) - (baseline - 44800#)) < 0.01
    ws.Range("P23").Value2 = "PILOT CONTACT CHECK"
    TestRow 28, "Job contact edit reaches Suppliers", CStr(ss.Cells(cr, 7).Value2) = "PILOT CONTACT CHECK"
    ss.Cells(cr, 7).Value2 = "PILOT REVERSE CHECK"
    Application.Calculate
    TestRow 29, "Supplier contact edit reaches job", CStr(ws.Range("P23").Value2) = "PILOT REVERSE CHECK"
    TestRow 30, "Original quote URL is still present", Len(CStr(qs.Cells(qr, 14).Value2)) > 0 And ws.Range("M42").Hyperlinks.Count = 1
    GoTo Restore
Failed:
    msg = Err.Description
Restore:
    On Error Resume Next
    mBusy = True
    If qr > 0 Then
        qs.Unprotect PW: ss.Unprotect PW: ws.Unprotect PW
        SetData qs.Cells(qr, 8), oldFinal: SetData qs.Cells(qr, 7), oldOriginal: SetData qs.Cells(qr, 6), oldStatus: SetData qs.Cells(qr, 9), oldCurrency
        SetData qs.Cells(qr, 5), oldScope: SetData ss.Cells(cr, 7), oldPhone
        ws.Range("AA3").Value2 = oldQID: ws.Range("P14").Value2 = oldPick
        RefreshAll: ConfigureEditors True: SnapshotSources
        restored = (CStr(qs.Cells(qr, 8).Value2) = CStr(oldFinal) And CStr(qs.Cells(qr, 6).Value2) = CStr(oldStatus) And CStr(ss.Cells(cr, 7).Value2) = CStr(oldPhone))
    End If
    TestRow 31, "Temporary values restored", restored
    tr.Unprotect PW
    For r = 16 To 31
        If CStr(tr.Cells(r, 17).Value2) <> "PASS" Then failed = failed + 1
    Next r
    tr.Range("A9").Value2 = "EXCEL CHECKS: " & IIf(failed = 0 And Len(msg) = 0, "PASS", "REVIEW REQUIRED") & vbCrLf & "Run at " & Format$(Now, "yyyy-mm-dd hh:nn") & IIf(Len(msg) > 0, vbCrLf & msg, "")
    tr.Protect Password:=PW, UserInterfaceOnly:=True, AllowFiltering:=True
    mBusy = False: mTesting = False
    tr.Activate
    On Error GoTo 0
    If Not restored Then MsgBox "IMPORTANT: restoration could not be fully verified. Close this test copy without saving, and reopen the unchanged copy.", vbCritical
End Sub
