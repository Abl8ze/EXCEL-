#!/usr/bin/env python3
"""Read an XLSX/XLSM package without Excel, VBA execution, network access or saving it.

Usage: python tools/inspect_workbook.py --input "input/current/file.xlsm" --out "reports/local_inspection"
Only a NEW output directory is allowed. No third-party modules are required.
The report is structural evidence, NOT an Excel compilation or runtime test.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import posixpath
import re
import sys
from pathlib import Path
from zipfile import ZipFile, BadZipFile
import xml.etree.ElementTree as ET

MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_DOC = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
REL_PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
NS = {"s": MAIN, "r": REL_DOC}
LIMIT_TOTAL = 300 * 1024 * 1024
LIMIT_PART = 80 * 1024 * 1024


def local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def json_write(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def plain_attrs(node: ET.Element) -> dict:
    return {local(k): v for k, v in node.attrib.items()}


def xml_value(node: ET.Element) -> dict:
    result = {"tag": local(node.tag), "attributes": plain_attrs(node)}
    if node.text and node.text.strip():
        result["text"] = node.text
    if len(node):
        result["children"] = [xml_value(child) for child in node]
    return result


def relationship_path(owner: str) -> str:
    return posixpath.join(posixpath.dirname(owner), "_rels", posixpath.basename(owner) + ".rels")


def relationships(z: ZipFile, owner: str) -> dict:
    name = relationship_path(owner)
    if name not in z.namelist():
        return {}
    found = {}
    for node in ET.fromstring(z.read(name)):
        item = dict(node.attrib)
        if item.get("TargetMode") != "External":
            target = item.get("Target", "")
            item["resolved_package_part"] = posixpath.normpath(
                target.lstrip("/") if target.startswith("/")
                else posixpath.join(posixpath.dirname(owner), target)
            )
        found[item.get("Id", "")] = item
    return found


def string_text(node: ET.Element | None) -> str:
    return "" if node is None else "".join(t.text or "" for t in node.findall(".//s:t", NS))


def cell_record(cell: ET.Element, shared: list[str]) -> dict:
    kind = cell.get("t", "n")
    value_node = cell.find("s:v", NS)
    raw = value_node.text if value_node is not None else None
    formula_node = cell.find("s:f", NS)
    result = {"address": cell.get("r"), "type": kind, "style_index": cell.get("s", "0")}
    if kind == "inlineStr":
        value = string_text(cell.find("s:is", NS))
    elif kind == "s" and raw is not None:
        value = shared[int(raw)]
    elif kind == "b" and raw is not None:
        value = raw == "1"
    else:
        # Keep numeric values as stored strings: this avoids changing IDs, precision or date serials.
        value = raw
    if formula_node is not None:
        result.update(formula="=" + (formula_node.text or ""),
                      formula_attributes=dict(formula_node.attrib),
                      cached_value=value)
    else:
        result["value"] = value
    return result


def inspect(source: Path, output: Path) -> dict:
    source = source.resolve(strict=True)
    if source.suffix.lower() not in (".xlsx", ".xlsm"):
        raise ValueError("Only XLSX/XLSM inputs are supported.")
    output = output.resolve()
    if output.exists():
        raise ValueError("Output must be a NEW directory. Existing results are never overwritten.")
    source_digest = hashlib.sha256(source.read_bytes()).hexdigest()
    with ZipFile(source) as z:
        members = z.infolist()
        if sum(m.file_size for m in members) > LIMIT_TOTAL or any(m.file_size > LIMIT_PART for m in members):
            raise ValueError("Package exceeds the conservative inspection size limit.")
        bad_crc = z.testzip()
        if bad_crc:
            raise ValueError("ZIP CRC check failed for " + bad_crc)
        xml_failures = []
        for m in members:
            if m.filename.endswith((".xml", ".rels")):
                try:
                    ET.fromstring(z.read(m.filename))
                except ET.ParseError as exc:
                    xml_failures.append({"part": m.filename, "error": str(exc)})
        book_part = "xl/workbook.xml"
        if book_part not in z.namelist():
            raise ValueError("Missing xl/workbook.xml; inspect package content types manually.")
        book = ET.fromstring(z.read(book_part))
        if book.tag != "{" + MAIN + "}workbook":
            raise ValueError("This exporter expects transitional SpreadsheetML. Source was not changed.")
        output.mkdir(parents=True)
        (output / "sheets").mkdir()
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            shared = [string_text(n) for n in ET.fromstring(z.read("xl/sharedStrings.xml"))]
        book_rels = relationships(z, book_part)
        manifest = {
            "source_filename": source.name,
            "source_sha256": source_digest,
            "source_bytes": source.stat().st_size,
            "mode": "Read-only OOXML inspection; no workbook rewrite, no VBA execution or recalculation",
            "important": "Cached formula values are stored values, not independently verified results. Sheet JSONL omits style-only empty cells; original XLSX/XLSM preserves them.",
            "excel_open_test": "NOT TESTED",
            "vba_compile_test": "NOT TESTED",
            "event_tests": "NOT TESTED",
            "zip_crc": "OK",
            "xml_parse_failures": xml_failures,
            "contains_vba_project_part": "xl/vbaProject.bin" in z.namelist(),
            "defined_names": [xml_value(n) for n in book.findall("s:definedNames/s:definedName", NS)],
            "calculation_properties": plain_attrs(book.find("s:calcPr", NS)) if book.find("s:calcPr", NS) is not None else {},
            "workbook_relationships": book_rels,
            "package_parts": [{"name": m.filename, "bytes": m.file_size} for m in members],
            "sheets": [],
        }
        cached_errors, all_links, by_name = [], [], {}
        structures = ["sheetPr", "dimension", "sheetViews", "sheetFormatPr", "cols", "sheetProtection", "autoFilter", "mergeCells", "dataValidations", "conditionalFormatting", "printOptions", "pageMargins", "pageSetup", "headerFooter", "rowBreaks", "colBreaks", "drawing", "legacyDrawing", "controls", "tableParts", "extLst"]
        for index, sheet in enumerate(book.findall("s:sheets/s:sheet", NS), 1):
            title = sheet.get("name", "")
            rid = sheet.get("{" + REL_DOC + "}id", "")
            target = book_rels[rid]["resolved_package_part"]
            root = ET.fromstring(z.read(target))
            rels = relationships(z, target)
            cells = []
            for node in root.findall("s:sheetData/s:row/s:c", NS):
                if node.find("s:v", NS) is None and node.find("s:f", NS) is None and node.find("s:is", NS) is None:
                    continue
                item = cell_record(node, shared)
                cells.append(item)
                if item["type"] == "e":
                    cached_errors.append({"sheet": title, **item})
            by_name[title] = {c["address"]: c for c in cells}
            stem = f"{index:02d}_" + re.sub(r"[^A-Za-z0-9_.-]+", "_", title)
            filename = stem + ".jsonl"
            with (output / "sheets" / filename).open("w", encoding="utf-8", newline="\n") as file:
                for item in cells:
                    file.write(json.dumps(item, ensure_ascii=False) + "\n")
            links = []
            for node in root.findall("s:hyperlinks/s:hyperlink", NS):
                item = plain_attrs(node)
                if item.get("id") in rels:
                    item["relationship"] = rels[item["id"]]
                links.append(item)
                all_links.append({"sheet": title, **item})
            info = {
                "name": title, "state": sheet.get("state", "visible"),
                "sheet_id": sheet.get("sheetId"), "part": target,
                "cell_file": "sheets/" + filename,
                "populated_cell_count": len(cells),
                "formula_count": sum("formula" in c for c in cells),
                "layout_and_validation": [xml_value(n) for n in root if local(n.tag) in structures],
                "row_properties": [dict(n.attrib) for n in root.findall("s:sheetData/s:row", NS)],
                "hyperlinks": links, "relationships": rels,
            }
            manifest["sheets"].append(info)
        counts = {}
        registers = {}
        for name, last in [("Jobs", 258), ("Quotes", 258), ("Suppliers", 508)]:
            mapping = by_name.get(name, {})
            headers = {re.sub(r"\d+", "", a): c.get("value") for a, c in mapping.items() if re.search(r"\d+$", a).group() == "8" and "formula" not in c}
            rows = []
            for row in range(9, last + 1):
                record_id = mapping.get(f"A{row}", {}).get("value")
                if record_id in (None, ""):
                    continue
                record = {"row": row, "id": record_id, "fields": {}}
                for col, label in headers.items():
                    cell = mapping.get(f"{col}{row}", {})
                    if not cell:
                        continue
                    record["fields"][str(label)] = {"address": f"{col}{row}", **{k: v for k, v in cell.items() if k != "address"}}
                rows.append(record)
            registers[name] = {"headers_at_row_8": headers, "rows": rows}
            counts[name + "_populated_rows"] = len(rows)
        suppliers = registers.get("Suppliers", {}).get("rows", [])
        counts["distinct_supplier_ids"] = len({r["id"] for r in suppliers})
        counts["original_quote_url_entries"] = sum(bool(r["fields"].get("Original quote link", {}).get("value")) for r in registers.get("Quotes", {}).get("rows", []))
        counts["job_tabs"] = sum(s["name"].startswith("JOB ") for s in manifest["sheets"])
        counts["visible_sheets"] = sum(s["state"] == "visible" for s in manifest["sheets"])
        manifest["reference_counts"] = counts
        manifest["stored_error_cells"] = cached_errors
        json_write(output / "structure.json", manifest)
        json_write(output / "registers.json", registers)
        json_write(output / "hyperlinks.json", all_links)
        json_write(output / "stored_error_cells.json", cached_errors)
        lines = ["# Read-only workbook snapshot", "", f"Source: `{source.name}`", f"SHA-256: `{source_digest}`", "", "No macros were run; no formulas were recalculated; no workbook was changed.", "Stored/cached values are NOT a live Excel test. Numeric values are represented as stored strings.", "", "## Observed counts", ""]
        lines.extend(f"- {key}: {value}" for key, value in counts.items())
        lines += ["", "## Worksheet index", "", "| Sheet | State | Formulas | Cell snapshot |", "|---|---|---:|---|"]
        lines.extend(f"| {s['name']} | {s['state']} | {s['formula_count']} | `{s['cell_file']}` |" for s in manifest["sheets"])
        lines += ["", "structure.json contains all defined names, data-validation references, protection, layout and package metadata.", "registers.json contains the populated Jobs, Quotes and Suppliers records, with formulas and stored values distinguished.", "hyperlinks.json contains hyperlink objects; formula-generated HYPERLINK addresses are preserved in the sheet snapshots.", "Original and revised quote URLs stored as ordinary cell text are included in registers.json.", "", "Excel open, compile, button, event and save/reopen tests: NOT TESTED."]
        (output / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if hashlib.sha256(source.read_bytes()).hexdigest() != source_digest:
        raise RuntimeError("Source hash changed during inspection; stop and investigate.")
    return {"source": source.name, "sha256": source_digest, "counts": counts, "stored_error_cells": len(cached_errors), "xml_parse_errors": len(xml_failures)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(inspect(args.input, args.out), ensure_ascii=False, indent=2))
        return 0
    except (OSError, KeyError, ValueError, BadZipFile, ET.ParseError, RuntimeError) as exc:
        print("Inspection stopped: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
