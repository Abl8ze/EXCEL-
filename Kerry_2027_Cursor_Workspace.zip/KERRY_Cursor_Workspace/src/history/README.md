# Historical VBA versions: comparison only

These files are alternate versions of the SAME module, with internal name KerryPilot.
Never import them all together. They are intentionally kept for actual source diffs and defect provenance.

- KerryPilot_original.bas: extracted unchanged from the original Professional Pilot package.
- KerryPilot_CompileFix_v1.bas: unchanged first supplied patch.
- Current v2: ../current/KerryPilot.bas.

No version here should replace the currently imported project without first checking the actual local file.
