# KERRY 2027 – start her

Denne mappe samler materiale til fejlfinding i Cursor. Det er **ikke en ny rettet Excel-fil**.
Excel-filerne og den seneste kode er kopieret uændret. Dine nuværende arbejdsfiler overskrives ikke.

## Det eneste, der mangler

Din lokale **Dock manager test 1.xlsm** med de importerede makroer er ikke uploadet til samtalen og findes derfor ikke i denne pakke.

**Kopiér den fil ind i `input/current` i den udpakkede mappe.** Kopiér – flyt ikke originalen. Undlad at omdøbe en af de medfølgende `.xlsx`-filer til `.xlsm`; det er ikke den samme fil.

Ved kopiering: Gem din lokale testfil, så de seneste importerede kodemoduler er med. Luk kun denne testfil, og kopiér den derefter. Kør ikke testmakroerne før Cursor har gennemgået dem. Har du ikke testfilen ved hånden, kan Cursor begynde med den medfølgende kildekode, men ikke fastslå indholdet af dit lokale VBA-projekt.

## Start i Cursor

1. Pak hele ZIP-filen ud i en lokal testmappe.
2. Kopiér **Dock manager test 1.xlsm** ind i `input/current`.
3. Åbn mappen **KERRY_Cursor_Workspace** i Cursor. Det er mappen, hvor `AGENTS.md` og denne fil ligger.
4. Skriv i Cursor-chatten:

> Læs AGENTS.md og CURSOR_START_HER.md. Undersøg filerne i denne mappe og min testfil i input/current. Start med en konkret diagnose og reparationsplan uden at ændre originalerne. Guid mig kun ét manuelt trin ad gangen.

Du skal ikke genimportere alle kodefilerne eller skrive kode selv.

## Hvad mappen indeholder

| Mappe/fil | Formål |
|---|---|
| `CURSOR_START_HER.md` | Den samlede opgave, fejlbeskrivelse og dine krav. |
| `AGENTS.md` | Faste instruktioner til agenten om sikkerhed, arbejdsmetode og sprog. |
| `input/current` | Her lægger du din lokale `.xlsm`-testfil. |
| `input/reference` | Professionel pilot, den tidligere fungerende Clean-grundfil og den oprindelige quotation tracker. |
| `src/current` | `KerryPilot.bas` fra CompileFix_v2 samt `CKerryEvents.cls`. Ikke bekræftet kompileret. |
| `src/history` | Tidligere kodeversioner – kun til sammenligning, ikke samlet import. |
| `snapshots/reference_pilot` | Læsbare udtræk af ark, celledata, formler, navne, dropdowns og links. |
| `evidence` | Fejlbilleder og eksisterende layoutbilleder. |
| `docs` | Datamodel, testplan, versionsforskelle og kilder. |
| `history` | Gamle installations-/testrapporter. De er ikke bevis for, at den nuværende kode virker. |
| `tools` | Et read-only værktøj til at udtrække din lokale fil uden at køre VBA. |
| `output` | Her kan Cursor lægge nye rapporter og testkopier. |

Tilbudslinks er med; selve de eksterne PDF-tilbud er ikke vedlagt. Et bevaret link er ikke en garanti for adgang til dokumentet.

Materialet indeholder virksomhedens kontakt- og tilbudsoplysninger. Brug det i den arbejdssammenhæng og med de tilladelser, der gælder hos jer; det skal ikke lægges i et offentligt repository.
