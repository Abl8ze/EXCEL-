# Aktuel status og bevisgrundlag

## Bekræftet i samtalen

- Brugeren kunne åbne Kerry_2027_Clean.xlsx efter flere mislykkede tidligere forsøg.
- Brugeren har gemt en testfil som **Dock manager test 1.xlsm**, åbnet VBA-editoren og vist KerryPilot under Modules samt CKerryEvents under Class Modules.
- Der er vist to native Excel-kompileringsfejl: Syntax error ved RateFor-deklarationen, derefter Duplicate declaration in current scope i RunPilotChecks.
- Den seneste leverede kildefil er CompileFix_v2. En efterfølgende fejlfri kompilering er **ikke** bekræftet.
- Den lokale Dock manager test 1.xlsm er **ikke tilgængelig i denne pakke** før brugeren selv tilføjer den.

## Kontrolleret ved oprettelse af denne pakke

- Reference-XLSX og VBA-kilde er kopieret byte-for-byte; se FILE_MANIFEST.json og docs/COPY_PROVENANCE.json.
- Det gamle pilotarkiv indeholder samme CKerryEvents.cls som den senere separat leverede klassefil.
- Tekstudtræk er lavet read-only fra Professional_Pilot.xlsx. Ingen VBA blev kørt, ingen priser blev ændret, ingen formler genberegnet, ingen regneark gemt igen.
- Gemte beregningsværdier er tydeligt skilt fra formler og er ikke en ny beregningstest.
- Arkivernes CRC/XML-parsebarhed kontrolleres, men det er ikke native Excel-kompilering eller fuld OOXML-validering.

## Stadig ikke verificeret

V2-import i brugerens fil; hele projektets kompilering; StartPilot; knapper; tovejs-events; budget efter brugerindtastning; testgendannelse; gemning/genåbning med aktiv VBA. Der skal bruges observerede testresultater i Excel.

## Bevidst udeladt

Tidligere fejlramte Job_Workspace*.xlsm, Data_Recovery.xlsx og mellemversioner med supplier-faner. De skal ikke genbruges som fungerende udgangspunkt. Historisk fejlbeskrivelse og screenshot er med. Eksterne PDF-tilbud og SharePoint-dokumenter er ikke hentet; kun de allerede eksisterende links er med.
