# Current supplied source, not verified compiled

`KerryPilot.bas` is byte-identical to the supplied `KerryPilot_CompileFix_v2.bas`.
Its disk filename was shortened; no code was changed for this package.
Internal names: standard module **KerryPilot**, class module **CKerryEvents**.

There is no evidence yet that this exact pair was imported, compiled and run in the user's local file.
Inspect the imported code before deciding what to replace. Import at most ONE KerryPilot version.
Historical variants are in `../history` for diagnosis only. This folder is NOT the current workbook itself.
Keep the original file encoding/newlines when importing. Do not add Markdown fences to VBA files.
