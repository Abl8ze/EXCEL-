# Source versions and procedure index

All copies retain source bytes; no source repair was made while packaging.

| Version | Package path | Bytes | SHA-256 |
|---|---|---:|---|
| original | `src/history/KerryPilot_original.bas` | 59905 | `0b342cdae8a9a67634aca1eb4ba59e9026ede962ce8028a956cbde6275e9da35` |
| compilefix_v1 | `src/history/KerryPilot_CompileFix_v1.bas` | 59913 | `d46fccaf5c9a55a5090942aa34e7a97229ee9c38e1d6c90739fa1450d636eb0a` |
| compilefix_v2 | `src/current/KerryPilot.bas` | 60013 | `d07b47d8e812cd7a2d33455749059a7be3b779e8fde208e4a129be07145051bf` |

Latest source procedure line numbers (text reference only, not compiler output):

| Line | Declaration |
|---:|---|
| 19 | `Public Sub Auto_Open()` |
| 23 | `Public Sub StartPilot()` |
| 71 | `Public Function PilotIsActive() As Boolean` |
| 75 | `Private Function IsPage(ByVal ws As Object) As Boolean` |
| 82 | `Private Function IsEditor(ByVal ws As Object) As Boolean` |
| 87 | `Private Function FindRow(ByVal sn As String, ByVal col As Long, ByVal ident As String) As Long` |
| 101 | `Private Function ChoiceID(ByVal value As Variant) As String` |
| 109 | `Private Function HasSheet(ByVal name As String) As Boolean` |
| 117 | `Private Function PageForJob(ByVal jobID As String) As Worksheet` |
| 129 | `Private Function JobMap() As Variant` |
| 133 | `Private Function ContactMap() As Variant` |
| 137 | `Private Function QuoteMap() As Variant` |
| 141 | `Private Function SourceArea(ByVal sn As String) As String` |
| 151 | `Private Sub SnapshotSources()` |
| 159 | `Private Sub RollbackSources()` |
| 168 | `Private Sub SetData(ByVal cell As Range, ByVal value As Variant)` |
| 182 | `Private Sub PutPlan(ByVal plan As Collection, ByVal sn As String, ByVal row As Long, ByVal col As Long, ByVal value As Variant)` |
| 187 | `Private Function Proposed(ByVal plan As Collection, ByVal sn As String, ByVal row As Long, ByVal col As Long) As Variant` |
| 195 | `Private Function Allowed(ByVal value As Variant, ByVal listName As String, Optional ByVal blankOK As Boolean = True) As Boolean` |
| 204 | `Private Function ValidMoney(ByVal value As Variant) As Boolean` |
| 211 | `Private Function ValidDate(ByVal value As Variant) As Boolean` |
| 227 | `Private Function RateFor(ByVal currencyCode As String) As Double` |
| 238 | `Private Function ValidatePlan(ByVal plan As Collection) As String` |
| 291 | `Private Function ResolveSelections(ByVal plan As Collection) As Boolean` |
| 325 | `Private Sub CommitPlan(ByVal plan As Collection)` |
| 352 | `Private Sub CapturePagePlan(ByVal ws As Worksheet, ByVal target As Range, ByVal plan As Collection)` |
| 378 | `Private Function SourceEditable(ByVal sn As String, ByVal col As Long, ByVal row As Long) As Boolean` |
| 388 | `Public Sub HandleChange(ByVal sh As Object, ByVal target As Range)` |
| 473 | `Private Sub AddListName(ByVal name As String, ByVal area As String)` |
| 480 | `Private Sub AddValidation(ByVal cell As Range, ByVal listName As String)` |
| 492 | `Private Sub RebuildLists()` |
| 549 | `Private Sub UpdateJobLinks()` |
| 566 | `Private Sub SetExternalLink(ByVal cell As Range, ByVal address As String)` |
| 574 | `Private Sub SetInternalLink(ByVal cell As Range, ByVal targetSheet As String, ByVal targetCell As String, Optional ByVal caption As String = "")` |
| 580 | `Private Sub RefreshPage(ByVal ws As Worksheet)` |
| 624 | `Private Sub RefreshSupplierJobs()` |
| 636 | `Private Sub RefreshDocumentLinks()` |
| 669 | `Private Sub RefreshPrintAreas()` |
| 689 | `Private Sub RefreshAll()` |
| 705 | `Private Sub UnlockCell(ByVal ws As Worksheet, ByVal address As String, ByVal active As Boolean)` |
| 709 | `Private Sub ConfigureEditors(ByVal active As Boolean)` |
| 765 | `Private Sub Button(ByVal ws As Worksheet, ByVal area As String, ByVal name As String, ByVal caption As String, ByVal macro As String)` |
| 791 | `Private Sub InstallControls(ByVal ws As Worksheet)` |
| 806 | `Public Sub CreateJob()` |
| 860 | `Public Sub OpenAddSupplier()` |
| 885 | `Private Sub PrefillForm(ByVal form As Worksheet, ByVal changed As Range)` |
| 914 | `Private Function FreeRow(ByVal sn As String) As Long` |
| 922 | `Private Function NewID(ByVal sn As String, ByVal col As Long, ByVal prefix As String, ByVal digits As Long) As String` |
| 933 | `Public Sub SaveSupplierQuote()` |
| 1024 | `Private Sub ApplyJobView()` |
| 1037 | `Public Sub ToggleJobView()` |
| 1050 | `Private Sub ApplySupplierFilter()` |
| 1061 | `Public Sub HandleFollowLink(ByVal sh As Object, ByVal target As Hyperlink)` |
| 1079 | `Public Sub HandleActivate(ByVal sh As Object)` |
| 1093 | `Public Sub BeforeWorkbookSave(ByRef cancel As Boolean)` |
| 1110 | `Public Sub AfterWorkbookSave(ByVal success As Boolean)` |
| 1122 | `Private Sub TestRow(ByVal row As Long, ByVal caption As String, ByVal ok As Boolean)` |
| 1131 | `Public Sub RunPilotChecks()` |
