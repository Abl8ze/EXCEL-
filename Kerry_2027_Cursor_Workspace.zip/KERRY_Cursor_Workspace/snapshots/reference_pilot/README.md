# Read-only workbook snapshot

Source: `Kerry_2027_Professional_Pilot.xlsx`
SHA-256: `f066e0f9e595995818b43d28dd89dfaf4e41e801e15bde57e2fc6d40d2e0989b`

No macros were run; no formulas were recalculated; no workbook was changed.
Stored/cached values are NOT a live Excel test. Numeric values are represented as stored strings.

## Observed counts

- Jobs_populated_rows: 81
- Quotes_populated_rows: 22
- Suppliers_populated_rows: 16
- distinct_supplier_ids: 14
- original_quote_url_entries: 19
- job_tabs: 12
- visible_sheets: 26

## Worksheet index

| Sheet | State | Formulas | Cell snapshot |
|---|---|---:|---|
| Overview | visible | 1754 | `sheets/01_Overview.jsonl` |
| Budget | visible | 33 | `sheets/02_Budget.jsonl` |
| Jobs | visible | 1500 | `sheets/03_Jobs.jsonl` |
| Suppliers | visible | 3484 | `sheets/04_Suppliers.jsonl` |
| Supplier Jobs | visible | 3500 | `sheets/05_Supplier_Jobs.jsonl` |
| Quotes | visible | 6000 | `sheets/06_Quotes.jsonl` |
| Negotiation Savings | visible | 1504 | `sheets/07_Negotiation_Savings.jsonl` |
| Print Summary | visible | 4281 | `sheets/08_Print_Summary.jsonl` |
| Create Job | visible | 5 | `sheets/09_Create_Job.jsonl` |
| Add Supplier | visible | 0 | `sheets/10_Add_Supplier.jsonl` |
| Read Me | visible | 0 | `sheets/11_Read_Me.jsonl` |
| Test Results | visible | 0 | `sheets/12_Test_Results.jsonl` |
| Vessel | visible | 0 | `sheets/13_Vessel.jsonl` |
| Lists | visible | 0 | `sheets/14_Lists.jsonl` |
| JOB 1001.02 | visible | 310 | `sheets/15_JOB_1001.02.jsonl` |
| JOB 1001.03 | visible | 310 | `sheets/16_JOB_1001.03.jsonl` |
| JOB 1303.01 | visible | 310 | `sheets/17_JOB_1303.01.jsonl` |
| JOB 1500.01 | visible | 310 | `sheets/18_JOB_1500.01.jsonl` |
| JOB 3103.01 | visible | 310 | `sheets/19_JOB_3103.01.jsonl` |
| JOB 3149.01 | visible | 310 | `sheets/20_JOB_3149.01.jsonl` |
| JOB 3149.02 | visible | 310 | `sheets/21_JOB_3149.02.jsonl` |
| JOB 3802.01 | visible | 310 | `sheets/22_JOB_3802.01.jsonl` |
| JOB 3805.02 | visible | 310 | `sheets/23_JOB_3805.02.jsonl` |
| JOB 3811.01 | visible | 310 | `sheets/24_JOB_3811.01.jsonl` |
| JOB 3811.02 | visible | 310 | `sheets/25_JOB_3811.02.jsonl` |
| JOB 3812.01 | visible | 310 | `sheets/26_JOB_3812.01.jsonl` |
| _Control | hidden | 44 | `sheets/27__Control.jsonl` |
| Archive Jobs | hidden | 0 | `sheets/28_Archive_Jobs.jsonl` |
| Archive Quotes | hidden | 0 | `sheets/29_Archive_Quotes.jsonl` |
| Archive Suppliers | hidden | 0 | `sheets/30_Archive_Suppliers.jsonl` |
| Archive Vessel | hidden | 0 | `sheets/31_Archive_Vessel.jsonl` |
| Archive Lists | hidden | 0 | `sheets/32_Archive_Lists.jsonl` |
| Archive Budget | hidden | 0 | `sheets/33_Archive_Budget.jsonl` |
| _PilotState | veryHidden | 0 | `sheets/34__PilotState.jsonl` |
| _PilotLists | veryHidden | 0 | `sheets/35__PilotLists.jsonl` |
| _JobTemplate | veryHidden | 310 | `sheets/36__JobTemplate.jsonl` |

structure.json contains all defined names, data-validation references, protection, layout and package metadata.
registers.json contains the populated Jobs, Quotes and Suppliers records, with formulas and stored values distinguished.
hyperlinks.json contains hyperlink objects; formula-generated HYPERLINK addresses are preserved in the sheet snapshots.
Original and revised quote URLs stored as ordinary cell text are included in registers.json.

Excel open, compile, button, event and save/reopen tests: NOT TESTED.
