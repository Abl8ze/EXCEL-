# Reference data model and exact mapping evidence

Source: `input/reference/Kerry_2027_Professional_Pilot.xlsx` plus `src/current/KerryPilot.bas`.
Workbook SHA-256: `f066e0f9e595995818b43d28dd89dfaf4e41e801e15bde57e2fc6d40d2e0989b`

**These are the reference files, not the user’s local XLSM. Reconfirm against the imported project before changing anything.**

## Active source registers

Headers are on row 8; data starts on row 9 in this pilot. Historical versions used other layouts.

### Jobs

| Column | Header | Row 9 kind |
|---|---|---|
| A | JobID | Input/static or hyperlink |
| B | Job title | Input/static or hyperlink |
| C | Department | Input/static or hyperlink |
| D | Job status | Input/static or hyperlink |
| E | Open job | Formula |
| F | Quote count | Formula |
| G | Selected EUR | Formula |
| H | Saved EUR | Formula |
| I | Yard | Input/static or hyperlink |
| J | Start | Empty/input |
| K | End | Empty/input |
| L | Job notes | Input/static or hyperlink |
| M | Specification | Input/static or hyperlink |
| N | Job document | Empty/input |
| O | Sample | Input/static or hyperlink |
| P | Page name | Empty/input |
| Q | Active sequence | Formula |
| R | Job choice | Formula |

### Suppliers

| Column | Header | Row 9 kind |
|---|---|---|
| A | SupplierID | Input/static or hyperlink |
| B | Supplier name | Input/static or hyperlink |
| C | Specialty / team | Input/static or hyperlink |
| D | ContactID | Input/static or hyperlink |
| E | Contact | Input/static or hyperlink |
| F | Email | Input/static or hyperlink |
| G | Phone | Empty/input |
| H | City / country | Empty/input |
| I | Supplier / contact notes | Input/static or hyperlink |
| J | Open jobs | Input/static or hyperlink |
| K | Quote count | Formula |
| L | Selected EUR | Formula |
| M | Saved EUR | Formula |
| N | Sample | Input/static or hyperlink |
| O | Primary supplier | Formula |
| P | Contact choice | Formula |
| Q | Supplier choice | Formula |

### Quotes

| Column | Header | Row 9 kind |
|---|---|---|
| A | QuoteID | Input/static or hyperlink |
| B | JobID | Input/static or hyperlink |
| C | SupplierID | Input/static or hyperlink |
| D | ContactID | Input/static or hyperlink |
| E | Scope / package | Input/static or hyperlink |
| F | Status | Input/static or hyperlink |
| G | Original price | Input/static or hyperlink |
| H | Final price | Empty/input |
| I | Currency | Input/static or hyperlink |
| J | RFQ sent | Empty/input |
| K | Received | Empty/input |
| L | Valid until | Empty/input |
| M | Quote reference | Empty/input |
| N | Original quote link | Input/static or hyperlink |
| O | Revised quote link | Empty/input |
| P | Quote notes | Input/static or hyperlink |
| Q | Negotiation notes | Empty/input |
| R | Sample | Input/static or hyperlink |
| S | Original filename | Input/static or hyperlink |
| T | Original job label | Input/static or hyperlink |
| U | Supplier | Formula |
| V | Contact name | Formula |
| W | Contact email | Formula |
| X | Contact phone | Formula |
| Y | Department | Formula |
| Z | Job title | Formula |
| AA | FX units per EUR | Formula |
| AB | Original EUR | Formula |
| AC | Latest price | Formula |
| AD | Latest EUR | Formula |
| AE | Savings currency | Formula |
| AF | Savings EUR | Formula |
| AG | Savings % | Formula |
| AH | Selected original EUR | Formula |
| AI | Selected EUR | Formula |
| AJ | Selected savings EUR | Formula |
| AK | Selected sequence | Formula |
| AL | Sequence on job | Formula |
| AM | Check | Formula |
| AN | Selected agreed original | Formula |
| AO | Contact check | Formula |
| AP | Open job | Formula |
| AQ | Open original | Input/static or hyperlink |
| AR | Open revised | Empty/input |
| AS | Job quote key | Formula |
| AT | Quote lookup key | Formula |

## Current source mappings

The address is the top-left input cell on an editable job page. The column is in the named central register. This is extracted from the supplied functions, not inferred from an old screenshot.

| Mapping | Job-page cell | Central register cell column | Header |
|---|---|---|---|
| JobMap | `D15` | `Jobs!B` (2) | Job title |
| JobMap | `D18` | `Jobs!C` (3) | Department |
| JobMap | `D19` | `Jobs!D` (4) | Job status |
| JobMap | `D20` | `Jobs!I` (9) | Yard |
| JobMap | `D21` | `Jobs!J` (10) | Start |
| JobMap | `J21` | `Jobs!K` (11) | End |
| JobMap | `A24` | `Jobs!M` (13) | Specification |
| JobMap | `A43` | `Jobs!L` (12) | Job notes |
| JobMap | `A51` | `Jobs!N` (14) | Job document |
| ContactMap | `P18` | `Suppliers!B` (2) | Supplier name |
| ContactMap | `P19` | `Suppliers!C` (3) | Specialty / team |
| ContactMap | `P21` | `Suppliers!E` (5) | Contact |
| ContactMap | `P22` | `Suppliers!F` (6) | Email |
| ContactMap | `P23` | `Suppliers!G` (7) | Phone |
| ContactMap | `P24` | `Suppliers!H` (8) | City / country |
| ContactMap | `A56` | `Suppliers!I` (9) | Supplier / contact notes |
| QuoteMap | `P27` | `Quotes!E` (5) | Scope / package |
| QuoteMap | `P28` | `Quotes!F` (6) | Status |
| QuoteMap | `P29` | `Quotes!I` (9) | Currency |
| QuoteMap | `P30` | `Quotes!G` (7) | Original price |
| QuoteMap | `P31` | `Quotes!H` (8) | Final price |
| QuoteMap | `P33` | `Quotes!M` (13) | Quote reference |
| QuoteMap | `P34` | `Quotes!J` (10) | RFQ sent |
| QuoteMap | `P35` | `Quotes!K` (11) | Received |
| QuoteMap | `P36` | `Quotes!L` (12) | Valid until |
| QuoteMap | `P37` | `Quotes!R` (18) | Sample |
| QuoteMap | `M40` | `Quotes!N` (14) | Original quote link |
| QuoteMap | `M44` | `Quotes!O` (15) | Revised quote link |
| QuoteMap | `M49` | `Quotes!Q` (17) | Negotiation notes |
| QuoteMap | `M54` | `Quotes!P` (16) | Quote notes |

## Job-page identity/selectors

| Cell | Role / stored reference value on JOB 3103.01 |
|---|---|
| `AA1` | `KERRY_JOB_V2` |
| `AA2` | `3103.01` |
| `AA3` | `3103.01-Q1` |
| `AA4` | `EDITABLE` |
| `P14` | `3103.01-Q1 | RENK | Main scope` |

Check all hidden identity markers, live quote dropdown binding and the source lookup before editing. IDs must remain stable after sorting.

## Shared lists in Lists

| Named list | Range | Stored choices |
|---|---|---|
| `lstJobStatus` | `'Lists'!$A$9:$A$17` | Draft, RFQ sent, Quote received, Clarification, Awarded, Closed, Cancelled, Pending, In progress |
| `lstQuoteStatus` | `'Lists'!$C$9:$C$18` | RFQ sent, Quote received, Clarification, Selected, Rejected, No quote, Expired, Pending, Quoted, Negotiating |
| `lstCurrency` | `'Lists'!$E$9:$E$14` | DKK, EUR, USD, SEK, NOK, GBP |
| `lstDepartment` | `'Lists'!$H$9:$H$15` | Engine, Accommodation, Bridge, Hull, Deck, Electrical, Other |
| `lstYesNo` | `'Lists'!$N$9:$N$10` | Yes, No |
| `lstPilotModes` | `'Lists'!$P$9:$P$11` | Existing contact, New contact, New supplier |

## Stored FX assumptions

Units of quote currency per one EUR; EUR amount = quote-currency amount / units-per-EUR. These are preserved workbook inputs, not refreshed market rates.

| Currency | Units per EUR |
|---|---:|
| DKK | 7.4755 |
| EUR | 1 |
| USD | 1.1403 |
| SEK | 11.29 |
| NOK | 10.84 |
| GBP | 0.86045 |

## Budget control formulas

| Cell | Label | Formula / value |
|---|---|---|
| `_Control!B1` | Professional pilot calculations | `Original input records retained` |
| `_Control!B6` | Allowance EUR | `=IFERROR(Allowance/VLOOKUP(AllowanceCurrency,Lists!$E$9:$F$14,2,FALSE),0)` |
| `_Control!B7` | Selected original | `=SUM(Quotes!$AH$9:$AH$258)` |
| `_Control!B8` | Selected latest | `=SUM(Quotes!$AI$9:$AI$258)` |
| `_Control!B9` | Negotiated savings | `=SUM(Quotes!$AJ$9:$AJ$258)` |
| `_Control!B10` | Remaining allowance | `=B6-B8` |
| `_Control!B11` | Savings rate | `=IFERROR(B9/SUM(Quotes!$AN$9:$AN$258),0)` |
| `_Control!B12` | Selected count | `=COUNTIF(Quotes!$F$9:$F$258,"Selected")` |
| `_Control!B13` | Agreed count | `=COUNTIFS(Quotes!$F$9:$F$258,"Selected",Quotes!$H$9:$H$258,">=0",Quotes!$H$9:$H$258,"<>")` |
| `_Control!B14` | Pending finals | `=B12-B13` |
| `_Control!B15` | Created active jobs | `=COUNT(Jobs!$Q$9:$Q$258)` |
| `_Control!B16` | All jobs | `=COUNTA(Jobs!$A$9:$A$258)` |
| `_Control!B17` | All quotes | `=COUNTA(Quotes!$A$9:$A$258)` |
| `_Control!B18` | Supplier count | `=SUM(Suppliers!$O$9:$O$508)` |
| `_Control!B19` | Selected price issues | `=COUNTIFS(Quotes!$F$9:$F$258,"Selected",Quotes!$AM$9:$AM$258,"<>OK",Quotes!$AM$9:$AM$258,"<>Final price pending",Quotes!$AM$9:$AM$258,"<>Price increased")` |
| `_Control!B20` | Scope overlaps | `=COUNTIFS(Quotes!$F$9:$F$258,"Selected",Quotes!$AM$9:$AM$258,"Selected scope overlap")` |
| `_Control!B21` | Allowance used | `=IFERROR(B8/B6,0)` |
| `_Control!B22` | Selected contacts issues | `=COUNTIFS(Quotes!$F$9:$F$258,"Selected",Quotes!$AO$9:$AO$258,"<>OK")` |
| `_Control!B23` | Agreed original | `=SUM(Quotes!$AN$9:$AN$258)` |
| `_Control!B24` | Contacts | `=COUNTA(Suppliers!$D$9:$D$508)` |
| `_Control!B25` | Created pages | `=COUNTIF(Jobs!$P$9:$P$258,"<>")` |
| `_Control!B26` | Unpriced selected | `=COUNTIFS(Quotes!$F$9:$F$258,"Selected",Quotes!$AD$9:$AD$258,"")` |

## Important capacity / integrity checks

The supplied code has FIRST=9, LASTQ=258 and LASTS=508. Inspect every range and name updater together before changing capacity. The existing pilot design describes up to 250 jobs/offers, 500 contact rows and 30 offers per job page. These are design bounds, not a guarantee that every boundary condition passes.

Different departments or work scopes must not be lost when selecting competing offers. Supplier company totals should not be multiplied by its number of contacts. Archive sheets must not contribute as live records.

Inspect `structure.json` for all sheet states, protected/merged cells, data validation, named ranges, hyperlinks and print/layout metadata. See the per-sheet JSONL files for every populated input/formula/cache cell. Long specification text and URLs are not truncated in those files.

The original PDFs are NOT embedded in this package; only the stored links are preserved.
