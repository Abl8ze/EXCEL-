# New work only

Use this directory for dated backups, work copies, local inspection reports, exported current modules, diffs and actual test results.
Never modify input originals. The files added here after extraction are not covered by the shipped package manifest.
