# Historical records, not current evidence

Previous_START_HER.html and Previous_TEST_REPORT.txt came from the original pilot package.
They describe the initial installation and earlier programmatic checks. They predate the screenshots of compile errors and the source fixes.
Do not follow their old import instructions blindly or interpret their PASS entries as native Excel acceptance of v2.
The current instructions are at the project root. No old corrupt .xlsm or recovery workbook is included.
